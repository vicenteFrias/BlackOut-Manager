package bm.cita.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Bean
    public WebClient agendaWebClient() {
        return WebClient.builder()
                .baseUrl("http://localhost:8086/api/v1/agenda") 
                .build();
    }

    @Bean
    public WebClient carteraWebClient() {
        return WebClient.builder()
                .baseUrl("http://localhost:8083/api/finanzas")
                .build();
    }
}