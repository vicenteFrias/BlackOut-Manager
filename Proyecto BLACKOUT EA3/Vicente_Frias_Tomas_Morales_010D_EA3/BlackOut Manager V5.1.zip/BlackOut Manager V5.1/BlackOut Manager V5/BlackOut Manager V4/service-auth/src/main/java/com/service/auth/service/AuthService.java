package com.service.auth.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.service.auth.model.Rol;
import com.service.auth.model.Usuario;
import com.service.auth.repository.UsuarioRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Service
public class AuthService {

    @Autowired 
    private UsuarioRepository usuarioRepo;

    @Autowired 
    private JwtService jwtService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PersistenceContext
    private EntityManager entityManager;

    public String registrar(Usuario usuario){
        usuario.setContrasena(passwordEncoder.encode(usuario.getContrasena()));
        // Rescatar los roles adjuntos y mapearlos a un Set gestionado por JPA
        if (usuario.getRoles() != null && !usuario.getRoles().isEmpty()) {
            Set<Rol> rolesAdjuntos = new HashSet<>(); // 🚨 Cambiado a HashSet
            
            for (Rol r : usuario.getRoles()) {
                // Buscamos el rol real en tu BD usando el EntityManager nativo
                Rol rolExistente = entityManager.createQuery(
                    "SELECT r FROM Rol r WHERE r.nombreRol = :nombre", Rol.class)
                    .setParameter("nombre", r.getNombreRol())
                    .getSingleResult();
                
                rolesAdjuntos.add(rolExistente);
            }
            usuario.setRoles(rolesAdjuntos);
        }

        // 3. Guardar de forma limpia en la BD sin colisiones de llaves
        usuarioRepo.save(usuario);
        return "Usuario registrado";
    }
    public String login(String username, String password){

        Usuario user = usuarioRepo.findByNombreUsuario(username)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        if (passwordEncoder.matches(password, user.getContrasena())){

            List<String> roles = user.getRoles().stream()
                    .map(Rol::getNombreRol).collect(Collectors.toList());
            return jwtService.generarToken(username, roles);
        }
        throw new RuntimeException("Credenciales invalidas");
    }

}

