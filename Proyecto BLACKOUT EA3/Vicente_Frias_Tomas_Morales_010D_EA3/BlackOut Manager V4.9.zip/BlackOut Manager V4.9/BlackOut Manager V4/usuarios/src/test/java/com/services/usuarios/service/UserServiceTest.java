package com.services.usuarios.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import com.services.usuarios.Service.UserService;
import com.services.usuarios.model.Usuario;
import com.services.usuarios.userRepository.UserRepository;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private WebClient citasWebClient;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @InjectMocks
    private UserService userService;

    private Usuario usuarioTatuador;
    private Usuario usuarioCliente;

    @BeforeEach
    void setUp() {
        // Configuramos un Tatuador base para las pruebas
        usuarioTatuador = new Usuario();
        usuarioTatuador.setNombre("Gaston");
        usuarioTatuador.setEmail("gaston@blackout.com");
        usuarioTatuador.setTipoUsuario("TATUADOR");

        // Configuramos un Cliente base para las pruebas
        usuarioCliente = new Usuario();
        usuarioCliente.setNombre("Pedro");
        usuarioCliente.setEmail("pedro@gmail.com");
        usuarioCliente.setTipoUsuario("CLIENTE");
    }

    @Test
    void registrarUsuario_CuandoEsCliente_DeberiaGuardarCorrectamente() {
        // Arrange (Preparar)
        Usuario usuarioGuardadoMock = new Usuario();
        usuarioGuardadoMock.setId(1L);
        usuarioGuardadoMock.setNombre("Pedro");
        usuarioGuardadoMock.setEmail("pedro@gmail.com");
        usuarioGuardadoMock.setTipoUsuario("CLIENTE");

        when(userRepository.save(any(Usuario.class))).thenReturn(usuarioGuardadoMock);

        // Act (Ejecutar)
        Usuario resultado = userService.registrarUsuario(usuarioCliente);

        // Assert (Verificar)
        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());
        assertEquals("Pedro", resultado.getNombre());
        assertEquals("CLIENTE", resultado.getTipoUsuario());
        
        // Verificamos que se guardó en BD una sola vez y NO se llamó al WebClient
        verify(userRepository, times(1)).save(usuarioCliente);
        verifyNoInteractions(citasWebClient);
    }

    @Test
    void registrarUsuario_CuandoEsTatuador_DeberiaGuardarYNotificarAWebClient() {
        // Arrange (Preparar Mock de la Base de Datos)
        Usuario usuarioGuardadoMock = new Usuario();
        usuarioGuardadoMock.setId(2L);
        usuarioGuardadoMock.setNombre("Gaston");
        usuarioGuardadoMock.setTipoUsuario("TATUADOR");
        
        when(userRepository.save(any(Usuario.class))).thenReturn(usuarioGuardadoMock);

        // Mockear toda la cadena encadenada (fluent API) del WebClient para evitar NullPointerException
        when(citasWebClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.bodyValue(any())).thenReturn((org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec) requestBodySpec);
        when(requestBodySpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(String.class)).thenReturn(reactor.core.publisher.Mono.just("Success"));

        // Act (Ejecutar)
        Usuario resultado = userService.registrarUsuario(usuarioTatuador);

        // Assert (Verificar)
        assertNotNull(resultado);
        assertEquals(2L, resultado.getId());
        assertEquals("TATUADOR", resultado.getTipoUsuario());
        
        verify(userRepository, times(1)).save(usuarioTatuador);
        verify(citasWebClient, times(1)).post(); // Comprueba que se gatilló la notificación asíncrona
    }

    @Test
    void buscarPorId_DeberiaRetornarUsuario_CuandoExiste() {
        // Arrange
        when(userRepository.findById(1L)).thenReturn(Optional.of(usuarioCliente));

        // Act
        Optional<Usuario> resultado = userService.buscarPorId(1L);

        // Assert
        assertTrue(resultado.isPresent());
        assertEquals("Pedro", resultado.get().getNombre());
    }

    @Test
    void eliminarUsuario_DeberiaLlamarAlRepository() {
        // Act
        userService.eliminarUsuario(1L);

        // Assert
        verify(userRepository, times(1)).deleteById(1L);
    }
}
