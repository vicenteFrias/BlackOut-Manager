package com.services.usuarios.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.services.usuarios.model.Usuario;
import com.services.usuarios.userRepository.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private WebClient citasWebClient;

    public List<Usuario> obtenerTodos() {
        return userRepository.findAll();
    }

   @Transactional
    public Usuario registrarUsuario(Usuario usuario) {
        // 1. Guardamos en la DB de Usuarios (MySQL Usuarios)
        Usuario guardado = userRepository.save(usuario);

        // 2. Si es TATUADOR: Notificamos para crear su perfil profesional
        if ("TATUADOR".equalsIgnoreCase(guardado.getTipoUsuario())) {
            notificarACitasNuevoTatuador(guardado);
        } 
        
        // 3. Si es CLIENTE: 
        // Por ahora solo lo guardamos. 
        // El MS de Citas obtendrá sus datos cuando el cliente haga login y agende.
        else if ("CLIENTE".equalsIgnoreCase(guardado.getTipoUsuario())) {
            System.out.println("✅ Cliente registrado: " + guardado.getNombre());
        }

        return guardado;
    }

    public Optional<Usuario> buscarPorId(Long id) {
        return userRepository.findById(id);
    }

    public void eliminarUsuario(Long id) {
        userRepository.deleteById(id);
    }

    public Usuario actualizarUsuario(Long id, Usuario userDetails) {
        return userRepository.findById(id).map(user -> {
            user.setNombre(userDetails.getNombre());
            user.setEmail(userDetails.getEmail());
            // No solemos actualizar el password así por seguridad, pero para nivel 1 está bien
            user.setPassword(userDetails.getPassword());
            return userRepository.save(user);
        }).orElse(null);
    }

    private void notificarACitasNuevoTatuador(Usuario guardado) {
        Map<String, Object> body = new HashMap<>();
        body.put("idUsuario", guardado.getId());
        body.put("nombre", guardado.getNombre());
        // Este mapa coincide con el @RequestBody Map del controlador de Citas que vimos antes

        citasWebClient.post()
                      .uri("/tatuadores/registrar")
                      .bodyValue(body)
                      .retrieve()
                      .bodyToMono(String.class)
                      .subscribe(
                 res -> System.out.println("✅ Perfil profesional creado en MS Citas"),
                 err -> System.err.println("❌ Error notificando a Citas: " + err.getMessage())
                );
    }

    
}
