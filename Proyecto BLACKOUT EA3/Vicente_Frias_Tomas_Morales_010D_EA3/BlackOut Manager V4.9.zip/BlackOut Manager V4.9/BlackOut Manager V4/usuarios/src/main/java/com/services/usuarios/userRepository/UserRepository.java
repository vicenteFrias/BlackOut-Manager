package com.services.usuarios.userRepository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.services.usuarios.model.Usuario;

@Repository 
public interface UserRepository extends JpaRepository<Usuario, Long>{
    // Necesario para validar que no existan emails duplicados antes de registrar
    Optional<Usuario> findByEmail(String email);
}
