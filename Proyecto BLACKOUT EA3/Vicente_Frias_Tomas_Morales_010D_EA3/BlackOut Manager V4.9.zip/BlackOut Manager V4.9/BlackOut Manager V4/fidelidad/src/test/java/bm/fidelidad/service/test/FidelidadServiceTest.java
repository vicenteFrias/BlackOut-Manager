package bm.fidelidad.service.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import bm.fidelidad.model.CuentaFidelidad;
import bm.fidelidad.repository.FidelidadRepository;
import bm.fidelidad.service.FidelidadService;

@ExtendWith(MockitoExtension.class)
public class FidelidadServiceTest {

    @Mock
    private FidelidadRepository repository;

    @InjectMocks
    private FidelidadService fidelidadService;

    // =========================================================================
    // 1. TESTS: sumarPuntos
    // =========================================================================
    @Test
    @DisplayName("Debería sumar puntos a una cuenta existente y actualizar su nivel")
    void sumarPuntos_CuentaExistente() {
        // Given
        Long clienteId = 1L;
        Integer puntosNuevos = 1500;

        CuentaFidelidad cuentaExistente = new CuentaFidelidad();
        cuentaExistente.setClienteId(clienteId);
        cuentaExistente.setPuntosAcumulados(600);
        cuentaExistente.setNivel("BRONCE");

        when(repository.findByClienteId(clienteId)).thenReturn(Optional.of(cuentaExistente));
        when(repository.save(any(CuentaFidelidad.class))).thenAnswer(i -> i.getArgument(0));

        // When
        CuentaFidelidad resultado = fidelidadService.sumarPuntos(clienteId, puntosNuevos);

        // Then
        assertNotNull(resultado);
        // 600 + 1500 = 2100 puntos totales
        assertEquals(2100, resultado.getPuntosAcumulados());
        // Al pasar los 2000 puntos, la lógica interna debería cambiarlo a "ORO"
        assertEquals("ORO", resultado.getNivel());

        verify(repository, times(1)).findByClienteId(clienteId);
        verify(repository, times(1)).save(cuentaExistente);
    }

    @Test
    @DisplayName("Debería crear una cuenta nueva con los puntos si el cliente no tenía una")
    void sumarPuntos_CuentaNueva() {
        // Given
        Long clienteId = 2L;
        Integer puntosNuevos = 1200;

        // Si no se encuentra la cuenta, el método usa .orElse(...) instanciando una vacía
        when(repository.findByClienteId(clienteId)).thenReturn(Optional.empty());
        when(repository.save(any(CuentaFidelidad.class))).thenAnswer(i -> i.getArgument(0));

        // When
        CuentaFidelidad resultado = fidelidadService.sumarPuntos(clienteId, puntosNuevos);

        // Then
        assertNotNull(resultado);
        assertEquals(1200, resultado.getPuntosAcumulados());
        // Al pasar los 1000 puntos (pero menos de 2000), califica como "PLATA"
        assertEquals("PLATA", resultado.getNivel());

        verify(repository, times(1)).save(any(CuentaFidelidad.class));
    }

    // =========================================================================
    // 2. TESTS: canjearPuntos
    // =========================================================================
    @Test
    @DisplayName("Debería canjear puntos con éxito y reajustar el nivel hacia abajo si aplica")
    void canjearPuntos_Exitoso() {
        // Given
        Long clienteId = 1L;
        Integer puntosACanjear = 4500;

        CuentaFidelidad cuenta = new CuentaFidelidad();
        cuenta.setClienteId(clienteId);
        cuenta.setPuntosAcumulados(5500);
        cuenta.setNivel("VIP"); // Tenía más de 5000 puntos

        when(repository.findByClienteId(clienteId)).thenReturn(Optional.of(cuenta));
        when(repository.save(any(CuentaFidelidad.class))).thenAnswer(i -> i.getArgument(0));

        // When
        CuentaFidelidad resultado = fidelidadService.canjearPuntos(clienteId, puntosACanjear);

        // Then
        assertNotNull(resultado);
        // 5500 - 4500 = 1000 puntos restantes
        assertEquals(1000, resultado.getPuntosAcumulados());
        // 1000 puntos exactos califica en la frontera de "PLATA"
        assertEquals("PLATA", resultado.getNivel());

        verify(repository, times(1)).save(cuenta);
    }

    @Test
    @DisplayName("Debería lanzar excepción si el cliente intenta canjear más puntos de los que posee")
    void canjearPuntos_FondosInsuficientes() {
        // Given
        Long clienteId = 1L;
        Integer puntosACanjear = 1000;

        CuentaFidelidad cuenta = new CuentaFidelidad();
        cuenta.setClienteId(clienteId);
        cuenta.setPuntosAcumulados(300); // Saldo insuficiente

        when(repository.findByClienteId(clienteId)).thenReturn(Optional.of(cuenta));

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            fidelidadService.canjearPuntos(clienteId, puntosACanjear);
        });

        assertTrue(exception.getMessage().contains("Fondos insuficientes"));
        // Regla de oro: Si hay error, jamás se debe llamar al método save del repositorio
        verify(repository, never()).save(any(CuentaFidelidad.class));
    }

    @Test
    @DisplayName("Debería lanzar excepción al canjear si el cliente ni siquiera está registrado")
    void canjearPuntos_ClienteNoExiste() {
        // Given
        Long clienteId = 99L;
        when(repository.findByClienteId(clienteId)).thenReturn(Optional.empty());

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            fidelidadService.canjearPuntos(clienteId, 500);
        });

        assertTrue(exception.getMessage().contains("no tiene una cuenta de fidelidad"));
        verify(repository, never()).save(any(CuentaFidelidad.class));
    }

    // =========================================================================
    // 3. TESTS: consultarSaldo
    // =========================================================================
    @Test
    @DisplayName("Debería retornar la cuenta de fidelidad al consultar el saldo de un cliente válido")
    void consultarSaldo_Exitoso() {
        // Given
        Long clienteId = 1L;
        CuentaFidelidad cuenta = new CuentaFidelidad();
        cuenta.setClienteId(clienteId);
        cuenta.setPuntosAcumulados(150);

        when(repository.findByClienteId(clienteId)).thenReturn(Optional.of(cuenta));

        // When
        CuentaFidelidad resultado = fidelidadService.consultarSaldo(clienteId);

        // Then
        assertNotNull(resultado);
        assertEquals(150, resultado.getPuntosAcumulados());
        verify(repository, times(1)).findByClienteId(clienteId);
    }

    @Test
    @DisplayName("Debería lanzar excepción al consultar saldo si el cliente no existe")
    void consultarSaldo_ClienteNoEncontrado() {
        // Given
        Long clienteId = 1L;
        when(repository.findByClienteId(clienteId)).thenReturn(Optional.empty());

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            fidelidadService.consultarSaldo(clienteId);
        });

        assertTrue(exception.getMessage().contains("Cuenta de fidelidad no encontrada"));
    }
}
