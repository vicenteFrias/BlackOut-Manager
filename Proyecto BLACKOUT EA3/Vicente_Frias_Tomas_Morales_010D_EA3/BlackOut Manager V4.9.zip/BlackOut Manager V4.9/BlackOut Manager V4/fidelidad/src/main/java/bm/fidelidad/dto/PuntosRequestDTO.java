package bm.fidelidad.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class PuntosRequestDTO {

    @NotNull(message = "Debe indicar el ID del cliente")
    private Long clienteId;

    @NotNull(message = "Debe indicar la cantidad de puntos")
    @Min(value = 1, message = "La cantidad mínima a procesar es 1 punto")
    private Integer cantidadPuntos;
}