package bm.fidelidad.controller;

import bm.fidelidad.dto.PuntosRequestDTO;
import bm.fidelidad.model.CuentaFidelidad;
import bm.fidelidad.service.FidelidadService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1/fidelidad")
public class FidelidadController {

    @Autowired
    private FidelidadService fidelidadService;

    /**
     * MS de Pagos o Citas llama a este endpoint al finalizar un tatuaje para dar puntos
     */
    @PostMapping("/sumar")
    public ResponseEntity<CuentaFidelidad> acumularPuntos(@Valid @RequestBody PuntosRequestDTO dto) {
        CuentaFidelidad cuentaActualizada = fidelidadService.sumarPuntos(dto.getClienteId(), dto.getCantidadPuntos());
        return ResponseEntity.ok(cuentaActualizada);
    }

    /**
     * El cliente usa este endpoint para transformar sus puntos en un descuento
     */
    @PostMapping("/canjear")
    public ResponseEntity<CuentaFidelidad> redimirPuntos(@Valid @RequestBody PuntosRequestDTO dto) {
        CuentaFidelidad cuentaActualizada = fidelidadService.canjearPuntos(dto.getClienteId(), dto.getCantidadPuntos());
        return ResponseEntity.ok(cuentaActualizada);
    }

    /**
     * Consulta el saldo actual y nivel VIP del cliente
     */
    @GetMapping("/cliente/{clienteId}")
    public ResponseEntity<CuentaFidelidad> verSaldo(@PathVariable Long clienteId) {
        return ResponseEntity.ok(fidelidadService.consultarSaldo(clienteId));
    }
}