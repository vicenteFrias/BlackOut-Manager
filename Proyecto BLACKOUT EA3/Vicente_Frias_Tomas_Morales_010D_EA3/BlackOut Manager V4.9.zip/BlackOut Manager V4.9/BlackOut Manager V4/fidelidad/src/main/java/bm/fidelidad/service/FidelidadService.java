package bm.fidelidad.service;

import bm.fidelidad.model.CuentaFidelidad;
import bm.fidelidad.repository.FidelidadRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class FidelidadService {

    private static final Logger log = LoggerFactory.getLogger(FidelidadService.class);

    @Autowired
    private FidelidadRepository repository;

    @Transactional
    public CuentaFidelidad sumarPuntos(Long clienteId, Integer puntosNuevos) {
        CuentaFidelidad cuenta = repository.findByClienteId(clienteId)
                .orElse(new CuentaFidelidad(null, clienteId, 0, "BRONCE", null));

        cuenta.setPuntosAcumulados(cuenta.getPuntosAcumulados() + puntosNuevos);
        actualizarNivel(cuenta);
        
        log.info("Se sumaron {} puntos al cliente {}. Total actual: {}", puntosNuevos, clienteId, cuenta.getPuntosAcumulados());
        return repository.save(cuenta);
    }

    @Transactional
    public CuentaFidelidad canjearPuntos(Long clienteId, Integer puntosACanjear) {
        CuentaFidelidad cuenta = repository.findByClienteId(clienteId)
                .orElseThrow(() -> new RuntimeException("El cliente no tiene una cuenta de fidelidad registrada."));

        // Regla de Negocio Crítica: Evitar saldo negativo
        if (cuenta.getPuntosAcumulados() < puntosACanjear) {
            log.error("Intento de canje fallido. Cliente {} quiso canjear {}, pero solo tiene {}", 
                      clienteId, puntosACanjear, cuenta.getPuntosAcumulados());
            throw new RuntimeException("Fondos insuficientes: No tienes suficientes puntos para realizar este canje.");
        }

        cuenta.setPuntosAcumulados(cuenta.getPuntosAcumulados() - puntosACanjear);
        actualizarNivel(cuenta);

        log.info("Canje exitoso. Cliente {} usó {} puntos. Saldo restante: {}", clienteId, puntosACanjear, cuenta.getPuntosAcumulados());
        return repository.save(cuenta);
    }

    public CuentaFidelidad consultarSaldo(Long clienteId) {
        return repository.findByClienteId(clienteId)
                .orElseThrow(() -> new RuntimeException("Cuenta de fidelidad no encontrada para este cliente."));
    }

    // Lógica interna para categorizar a los clientes fieles
    private void actualizarNivel(CuentaFidelidad cuenta) {
        int puntos = cuenta.getPuntosAcumulados();
        if (puntos >= 5000) {
            cuenta.setNivel("VIP");
        } else if (puntos >= 2000) {
            cuenta.setNivel("ORO");
        } else if (puntos >= 1000) {
            cuenta.setNivel("PLATA");
        } else {
            cuenta.setNivel("BRONCE");
        }
    }
}