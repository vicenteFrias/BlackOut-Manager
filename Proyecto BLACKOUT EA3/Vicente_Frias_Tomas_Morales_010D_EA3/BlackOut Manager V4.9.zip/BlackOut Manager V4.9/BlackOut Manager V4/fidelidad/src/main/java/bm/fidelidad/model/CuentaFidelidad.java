package bm.fidelidad.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import org.hibernate.annotations.UpdateTimestamp;
import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.v3.oas.annotations.media.Schema;

@Entity
@Table(name = "cuentas_fidelidad")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CuentaFidelidad {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(accessMode = Schema.AccessMode.READ_ONLY, description = "ID autoincremental generado por la BD")
    private Long id;

    @NotNull(message = "El ID del cliente es obligatorio")
    @Column(unique = true) // Cada cliente tiene una única cuenta de puntos
    private Long clienteId; 

    @Min(value = 0, message = "Los puntos no pueden ser negativos")
    private Integer puntosAcumulados;

    // Nivel del cliente: BRONCE, PLATA, ORO, VIP
    private String nivel;

    @UpdateTimestamp
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime ultimaActualizacion;
}