package bm.fidelidad.repository;

import bm.fidelidad.model.CuentaFidelidad;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface FidelidadRepository extends JpaRepository<CuentaFidelidad, Long> {
    
    // Buscar la billetera de puntos de un cliente específico
    Optional<CuentaFidelidad> findByClienteId(Long clienteId);
}