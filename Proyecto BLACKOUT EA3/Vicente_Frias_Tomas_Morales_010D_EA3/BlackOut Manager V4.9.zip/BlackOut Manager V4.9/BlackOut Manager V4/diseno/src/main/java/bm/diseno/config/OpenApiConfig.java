package bm.diseno.config;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;

@Configuration
public class OpenApiConfig {
    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("API BlackOut – Servicio de Diseno")
                        .version("1.0")
                        .description("Documentación centralizada del Sistema BlackOut"))
                // ESTO ES LO QUE SOLUCIONA EL "FAILED TO FETCH":
                .servers(List.of(
                        new Server().url("http://localhost:9090").description("Servidor a través del Gateway")
                ))
                // Añade el requerimiento de seguridad global para todos los endpoints
                .addSecurityItem(new SecurityRequirement().addList("BearerAuth"))
                // Define el esquema de seguridad indicando que usas portador Bearer con JWT
                .components(new Components()
                        .addSecuritySchemes("BearerAuth",
                        new SecurityScheme()
                                .name("BearerAuth")
                                .type(SecurityScheme.Type.HTTP)
                                .scheme("bearer")
                                .bearerFormat("JWT")));
    }
}
