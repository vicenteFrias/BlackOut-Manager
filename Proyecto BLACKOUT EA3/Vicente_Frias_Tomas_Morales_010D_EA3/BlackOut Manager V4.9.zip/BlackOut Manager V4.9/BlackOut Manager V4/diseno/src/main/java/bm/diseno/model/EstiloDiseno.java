package bm.diseno.model;

public enum EstiloDiseno {
    REALISMO,
    TRADICIONAL,
    BLACKWORK,
    ACUARELA,
    FLASH_EXCLUSIVO // Diseño único, se bloquea al reservarse
}