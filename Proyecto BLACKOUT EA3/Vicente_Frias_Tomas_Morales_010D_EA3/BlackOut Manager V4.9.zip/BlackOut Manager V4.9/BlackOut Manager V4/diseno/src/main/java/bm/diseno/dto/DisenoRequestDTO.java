package bm.diseno.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class DisenoRequestDTO {

    @NotBlank(message = "El nombre es obligatorio")
    private String nombre;

    @NotBlank(message = "La descripción detallada es obligatoria")
    private String descripcionDetallada;

    @NotBlank(message = "El estilo es obligatorio (Ej: BLACKWORK, FLASH_EXCLUSIVO)")
    private String estilo;

    @NotNull(message = "El precio es obligatorio")
    @Min(value = 1000, message = "El precio mínimo es 1000 CLP")
    private Integer precioBase;

    @NotNull(message = "Debe indicar el ID del tatuador")
    private Long tatuadorId;
}