package bm.diseno.service;

import bm.diseno.model.Diseno;
import bm.diseno.model.EstiloDiseno;
import bm.diseno.repository.DisenoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class DisenoService {

    private static final Logger log = LoggerFactory.getLogger(DisenoService.class);

    @Autowired
    private DisenoRepository repository;

    @Transactional
    public Diseno registrarDiseno(Diseno nuevoDiseno) {
        nuevoDiseno.setDisponible(true); // Todo diseño nuevo entra disponible al catálogo
        log.info("Registrando nuevo diseño: {}", nuevoDiseno.getNombre());
        return repository.save(nuevoDiseno);
    }

    public List<Diseno> listarDisponiblesPorTatuador(Long tatuadorId) {
        return repository.findByTatuadorIdAndDisponibleTrue(tatuadorId);
    }

    public List<Diseno> listarFlashesDisponibles() {
        return repository.findByEstiloAndDisponibleTrue(EstiloDiseno.FLASH_EXCLUSIVO);
    }

    @Transactional
    public Diseno reservarDiseno(Long idDiseno) {
        Diseno diseno = repository.findById(idDiseno)
                .orElseThrow(() -> new RuntimeException("Error: El diseño solicitado no existe en el catálogo."));

        if (!diseno.isDisponible()) {
            throw new RuntimeException("Conflicto: Este diseño ya fue reservado o tatuado a otro cliente.");
        }

        // Regla de Negocio: Si el diseño es un Flash Exclusivo, se bloquea para el resto
        if (diseno.getEstilo() == EstiloDiseno.FLASH_EXCLUSIVO) {
            log.info("Reservando diseño exclusivo: {}. Marcando como NO disponible.", diseno.getNombre());
            diseno.setDisponible(false);
        } else {
            log.info("Diseño {} reservado (Es reutilizable).", diseno.getNombre());
        }

        return repository.save(diseno);
    }

    @Transactional
    public void eliminarDiseno(Long id) {
        repository.deleteById(id);
    }
}