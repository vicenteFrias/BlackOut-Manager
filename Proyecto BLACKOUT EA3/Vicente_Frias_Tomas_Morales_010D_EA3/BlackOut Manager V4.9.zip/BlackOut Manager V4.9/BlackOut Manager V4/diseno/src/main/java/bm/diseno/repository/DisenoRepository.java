package bm.diseno.repository;

import bm.diseno.model.Diseno;
import bm.diseno.model.EstiloDiseno;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface DisenoRepository extends JpaRepository<Diseno, Long> {
    
    // Buscar todos los diseños disponibles de un tatuador específico
    List<Diseno> findByTatuadorIdAndDisponibleTrue(Long tatuadorId);

    // Buscar diseños por estilo (Ej: Mostrar solo los FLASH disponibles en vitrina)
    List<Diseno> findByEstiloAndDisponibleTrue(EstiloDiseno estilo);
}