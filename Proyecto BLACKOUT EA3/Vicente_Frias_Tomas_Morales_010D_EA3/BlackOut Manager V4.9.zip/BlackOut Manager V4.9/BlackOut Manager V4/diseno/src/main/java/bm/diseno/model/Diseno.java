package bm.diseno.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import org.hibernate.annotations.CreationTimestamp;
import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.v3.oas.annotations.media.Schema;

@Entity
@Table(name = "disenos")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Diseno {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(accessMode = Schema.AccessMode.READ_ONLY, description = "ID autoincremental generado por la BD")
    private Long id;

    @NotBlank(message = "El nombre o título del diseño es obligatorio")
    private String nombre;

    @NotBlank(message = "Debe incluir una descripción detallada del diseño")
    @Column(length = 1000)
    private String descripcionDetallada; // Reemplaza la imagen por una descripción textual

    @Enumerated(EnumType.STRING)
    private EstiloDiseno estilo;

    @NotNull(message = "Debe establecer un precio base")
    @Min(value = 0, message = "El precio base no puede ser negativo")
    private Integer precioBase;

    // Regla de Negocio: Indica si el diseño aún puede ser elegido por un cliente
    private boolean disponible; 

    @NotNull(message = "El ID del tatuador (autor) es obligatorio")
    private Long tatuadorId; // Relación lógica con el MS de Usuarios/Citas

    @CreationTimestamp
    @Column(updatable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime fechaCreacion;
}