package bm.diseno.controller;

import bm.diseno.dto.DisenoRequestDTO;
import bm.diseno.model.Diseno;
import bm.diseno.model.EstiloDiseno;
import bm.diseno.service.DisenoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1/disenos")
public class DisenoController {

    @Autowired
    private DisenoService disenoService;

    /**
     * El tatuador registra una idea o diseño en su catálogo textual
     */
    @PostMapping
    public ResponseEntity<Diseno> crearDiseno(@Valid @RequestBody DisenoRequestDTO dto) {
        Diseno diseno = new Diseno();
        diseno.setNombre(dto.getNombre());
        diseno.setDescripcionDetallada(dto.getDescripcionDetallada());
        diseno.setEstilo(EstiloDiseno.valueOf(dto.getEstilo().toUpperCase()));
        diseno.setPrecioBase(dto.getPrecioBase());
        diseno.setTatuadorId(dto.getTatuadorId());

        Diseno guardado = disenoService.registrarDiseno(diseno);
        return ResponseEntity.status(HttpStatus.CREATED).body(guardado);
    }

    /**
     * Catálogo disponible de un tatuador
     */
    @GetMapping("/tatuador/{id}")
    public ResponseEntity<List<Diseno>> verCatalogoTatuador(@PathVariable Long id) {
        List<Diseno> catalogo = disenoService.listarDisponiblesPorTatuador(id);
        return catalogo.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(catalogo);
    }

    /**
     * Ver todos los diseños exclusivos (Flash) disponibles en el estudio
     */
    @GetMapping("/flashes")
    public ResponseEntity<List<Diseno>> verFlashesDisponibles() {
        List<Diseno> flashes = disenoService.listarFlashesDisponibles();
        return flashes.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(flashes);
    }

    /**
     * Endpoint transaccional: Bloquea un diseño si es Flash
     */
    @PutMapping("/{id}/reservar")
    public ResponseEntity<Diseno> reservarDiseno(@PathVariable Long id) {
        Diseno reservado = disenoService.reservarDiseno(id);
        return ResponseEntity.ok(reservado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> borrarDiseno(@PathVariable Long id) {
        disenoService.eliminarDiseno(id);
        return ResponseEntity.noContent().build();
    }
}