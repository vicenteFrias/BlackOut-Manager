package bm.diseno.service.test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import bm.diseno.model.Diseno;
import bm.diseno.model.EstiloDiseno;
import bm.diseno.repository.DisenoRepository;
import bm.diseno.service.DisenoService;

@ExtendWith(MockitoExtension.class)
public class DisenoServiceTest {

    @Mock
    private DisenoRepository repository;

    @InjectMocks
    private DisenoService disenoService;

    // =========================================================================
    // 1. TEST: registrarDiseno
    // =========================================================================
    @Test
    @DisplayName("Debería registrar un diseño forzando su disponibilidad a true")
    void registrarDisenoTest() {
        // Given
        Diseno entrada = new Diseno();
        entrada.setNombre("Cráneo Tradicional");
        entrada.setDisponible(false); // Entra como false para probar que el método lo cambie

        when(repository.save(any(Diseno.class))).thenAnswer(i -> i.getArgument(0));

        // When
        Diseno resultado = disenoService.registrarDiseno(entrada);

        // Then
        assertNotNull(resultado);
        assertTrue(resultado.isDisponible(), "La regla de negocio debe forzar la disponibilidad a true");
        assertEquals("Cráneo Tradicional", resultado.getNombre());
        
        verify(repository, times(1)).save(entrada);
    }

    // =========================================================================
    // 2. TESTS: reservarDiseno (Manejo de Reglas de Negocio)
    // =========================================================================
    @Test
    @DisplayName("Debería reservar un diseño FLASH_EXCLUSIVO y cambiar su disponibilidad a false")
    void reservarDiseno_FlashExclusivo() {
        // Given
        Long idDiseno = 1L;
        Diseno disenoFlash = new Diseno();
        disenoFlash.setId(idDiseno);
        disenoFlash.setNombre("Dragón Oriental");
        disenoFlash.setEstilo(EstiloDiseno.FLASH_EXCLUSIVO);
        disenoFlash.setDisponible(true);

        when(repository.findById(idDiseno)).thenReturn(Optional.of(disenoFlash));
        when(repository.save(any(Diseno.class))).thenAnswer(i -> i.getArgument(0));

        // When
        Diseno resultado = disenoService.reservarDiseno(idDiseno);

        // Then
        assertNotNull(resultado);
        assertFalse(resultado.isDisponible(), "Al ser FLASH_EXCLUSIVO, debe quedar NO disponible (false)");
        
        verify(repository, times(1)).findById(idDiseno);
        verify(repository, times(1)).save(disenoFlash);
    }

    @Test
    @DisplayName("Debería reservar un diseño común manteniendo su disponibilidad en true por ser reutilizable")
    void reservarDiseno_Reutilizable() {
        // Given
        Long idDiseno = 2L;
        Diseno disenoComun = new Diseno();
        disenoComun.setId(idDiseno);
        disenoComun.setNombre("Letras Gothic");
        disenoComun.setEstilo(EstiloDiseno.REALISMO); // Cualquier estilo que NO sea FLASH_EXCLUSIVO
        disenoComun.setDisponible(true);

        when(repository.findById(idDiseno)).thenReturn(Optional.of(disenoComun));
        when(repository.save(any(Diseno.class))).thenAnswer(i -> i.getArgument(0));

        // When
        Diseno resultado = disenoService.reservarDiseno(idDiseno);

        // Then
        assertNotNull(resultado);
        assertTrue(resultado.isDisponible(), "Al no ser exclusivo, debe seguir disponible (true)");
        
        verify(repository, times(1)).save(disenoComun);
    }

    @Test
    @DisplayName("Debería lanzar excepción si el diseño ya se encuentra reservado")
    void reservarDiseno_ErrorYaReservado() {
        // Given
        Long idDiseno = 3L;
        Diseno disenoOcupado = new Diseno();
        disenoOcupado.setId(idDiseno);
        disenoOcupado.setDisponible(false); // Ya reservado previamente

        when(repository.findById(idDiseno)).thenReturn(Optional.of(disenoOcupado));

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            disenoService.reservarDiseno(idDiseno);
        });

        assertTrue(exception.getMessage().contains("Este diseño ya fue reservado o tatuado"));
        verify(repository, never()).save(any(Diseno.class));
    }

    @Test
    @DisplayName("Debería lanzar excepción si el ID del diseño no existe en el catálogo")
    void reservarDiseno_ErrorNoExiste() {
        // Given
        Long idDiseno = 99L;
        when(repository.findById(idDiseno)).thenReturn(Optional.empty());

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            disenoService.reservarDiseno(idDiseno);
        });

        assertTrue(exception.getMessage().contains("El diseño solicitado no existe"));
        verify(repository, never()).save(any(Diseno.class));
    }

    // =========================================================================
    // 3. TESTS: Listados
    // =========================================================================
    @Test
    @DisplayName("Debería listar diseños disponibles filtrados por Tatuador")
    void listarDisponiblesPorTatuadorTest() {
        // Given
        Long tatuadorId = 7L;
        when(repository.findByTatuadorIdAndDisponibleTrue(tatuadorId)).thenReturn(List.of(new Diseno()));

        // When
        List<Diseno> resultado = disenoService.listarDisponiblesPorTatuador(tatuadorId);

        // Then
        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        verify(repository, times(1)).findByTatuadorIdAndDisponibleTrue(tatuadorId);
    }

    @Test
    @DisplayName("Debería listar únicamente los diseños Flashes que estén disponibles")
    void listarFlashesDisponiblesTest() {
        // Given
        when(repository.findByEstiloAndDisponibleTrue(EstiloDiseno.FLASH_EXCLUSIVO)).thenReturn(List.of(new Diseno(), new Diseno()));

        // When
        List<Diseno> resultado = disenoService.listarFlashesDisponibles();

        // Then
        assertNotNull(resultado);
        assertEquals(2, resultado.size());
        verify(repository, times(1)).findByEstiloAndDisponibleTrue(EstiloDiseno.FLASH_EXCLUSIVO);
    }

    // =========================================================================
    // 4. TEST: eliminarDiseno
    // =========================================================================
    @Test
    @DisplayName("Debería invocar la eliminación física del diseño en el repositorio")
    void eliminarDisenoTest() {
        // Given
        Long idEliminar = 1L;
        doNothing().when(repository).deleteById(idEliminar);

        // When
        assertDoesNotThrow(() -> disenoService.eliminarDiseno(idEliminar));

        // Then
        verify(repository, times(1)).deleteById(idEliminar);
    }
}
