package bm.ficha.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Bean
    public WebClient citaWebClient() {
        return WebClient.builder()
                .baseUrl("http://localhost:8085/api/citas") // URL del MS de Citas
                .build();
    }
}