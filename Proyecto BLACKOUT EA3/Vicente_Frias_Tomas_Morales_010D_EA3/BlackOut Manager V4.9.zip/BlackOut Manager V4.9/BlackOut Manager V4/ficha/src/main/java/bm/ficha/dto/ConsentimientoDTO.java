package bm.ficha.dto;

import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ConsentimientoDTO {

    @NotNull(message = "El ID de la cita no puede ser nulo")
    private Long citaId;

    @AssertTrue(message = "Debe marcar la casilla de aceptación firmada del documento")
    private boolean firmaAceptada;

    private String alergias;
    private String enfermedadesCronicas;
    private String observacionesMedicas;
}