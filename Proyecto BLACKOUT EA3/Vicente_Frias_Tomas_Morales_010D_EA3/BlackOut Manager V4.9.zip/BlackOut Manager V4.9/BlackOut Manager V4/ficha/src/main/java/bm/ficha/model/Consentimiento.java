package bm.ficha.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.v3.oas.annotations.media.Schema;

@Entity
@Table(name = "consentimientos")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Consentimiento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(accessMode = Schema.AccessMode.READ_ONLY, description = "ID autoincremental generado por la BD")
    private Long id;

    @NotNull(message = "El ID de la cita es obligatorio para vincular la ficha médica")
    private Long citaId; // Relación lógica con MS Citas

    @AssertTrue(message = "Es obligatorio que el cliente acepte y firme el consentimiento legal para tatuarse")
    private boolean firmaAceptada; // Regla de negocio crítica

    private String alergias;            // Ej: "Alergia a la tinta roja" o "Ninguna"
    private String enfermedadesCronicas; // Ej: "Diabetes" o "Ninguna"
    
    @Column(length = 500)
    private String observacionesMedicas;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime fechaFirma;

    @PrePersist
    protected void onCreate() {
        this.fechaFirma = LocalDateTime.now();
    }
}