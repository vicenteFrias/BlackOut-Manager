package bm.ficha.repository;

import bm.ficha.model.Consentimiento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface ConsentimientoRepository extends JpaRepository<Consentimiento, Long> {
    
    // Buscar si una cita ya posee su respectivo consentimiento firmado
    Optional<Consentimiento> findByCitaId(Long citaId);
}