package bm.ficha.controller;

import bm.ficha.dto.ConsentimientoDTO;
import bm.ficha.model.Consentimiento;
import bm.ficha.service.FichaService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1/fichas")
public class FichaController {

    @Autowired
    private FichaService fichaService;

    /**
     * Guarda el consentimiento informado usando @Valid para activar las reglas del modelo.
     */
    @PostMapping("/consentimiento")
    public ResponseEntity<Consentimiento> crear(@Valid @RequestBody ConsentimientoDTO dto) {
        Consentimiento consentimiento = new Consentimiento();
        consentimiento.setCitaId(dto.getCitaId());
        consentimiento.setFirmaAceptada(dto.isFirmaAceptada());
        consentimiento.setAlergias(dto.getAlergias());
        consentimiento.setEnfermedadesCronicas(dto.getEnfermedadesCronicas());
        consentimiento.setObservacionesMedicas(dto.getObservacionesMedicas());

        Consentimiento guardado = fichaService.registrarConsentimiento(consentimiento);
        return ResponseEntity.status(HttpStatus.CREATED).body(guardado);
    }

    /**
     * Consulta el estado de consentimiento por el ID de la cita externa.
     */
    @GetMapping("/cita/{citaId}")
    public ResponseEntity<Consentimiento> consultarPorCita(@PathVariable Long citaId) {
        return ResponseEntity.ok(fichaService.obtenerPorCita(citaId));
    }

    /**
     * Lista todos los registros clínicos del estudio.
     */
    @GetMapping
    public ResponseEntity<List<Consentimiento>> listarTodo() {
        List<Consentimiento> lista = fichaService.obtenerTodas();
        return lista.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(lista);
    }

    /**
     * Elimina una ficha clínica si fuese necesario (Control manual de historial).
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> borrar(@PathVariable Long id) {
        fichaService.eliminarConsentimiento(id);
        return ResponseEntity.noContent().build();
    }
}