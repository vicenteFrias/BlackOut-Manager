package bm.ficha.service;

import bm.ficha.model.Consentimiento;
import bm.ficha.repository.ConsentimientoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class FichaService {

    private static final Logger log = LoggerFactory.getLogger(FichaService.class);

    @Autowired
    private ConsentimientoRepository repository;

    @Transactional
    public Consentimiento registrarConsentimiento(Consentimiento nuevoConsentimiento) {
        log.info("Procesando registro de consentimiento para la cita ID: {}", nuevoConsentimiento.getCitaId());

        // Regla de Negocio: No se puede duplicar el consentimiento para una misma cita
        repository.findByCitaId(nuevoConsentimiento.getCitaId()).ifPresent(c -> {
            throw new RuntimeException("Operación inválida: Ya existe un consentimiento registrado y firmado para esta cita.");
        });

        return repository.save(nuevoConsentimiento);
    }

    public Consentimiento obtenerPorCita(Long citaId) {
        return repository.findByCitaId(citaId)
                .orElseThrow(() -> new RuntimeException("Ficha médica no encontrada para la cita ID: " + citaId));
    }

    public List<Consentimiento> obtenerTodas() {
        return repository.findAll();
    }

    @Transactional
    public void eliminarConsentimiento(Long id) {
        if (!repository.existsById(id)) {
            throw new RuntimeException("No se puede eliminar: El registro médico no existe.");
        }
        repository.deleteById(id);
    }
}