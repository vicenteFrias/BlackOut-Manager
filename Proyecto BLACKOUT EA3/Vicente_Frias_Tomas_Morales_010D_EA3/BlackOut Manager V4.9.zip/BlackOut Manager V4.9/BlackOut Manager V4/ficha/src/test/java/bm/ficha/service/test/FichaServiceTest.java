package bm.ficha.service.test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import bm.ficha.model.Consentimiento;
import bm.ficha.repository.ConsentimientoRepository;
import bm.ficha.service.FichaService;

@ExtendWith(MockitoExtension.class)
public class FichaServiceTest {

    @Mock
    private ConsentimientoRepository repository;

    @InjectMocks
    private FichaService fichaService;

    // =========================================================================
    // 1. TESTS: registrarConsentimiento
    // =========================================================================
    @Test
    @DisplayName("Debería registrar un consentimiento exitosamente si la cita no tiene uno previo")
    void registrarConsentimiento_Exitoso() {
        // Given
        Long citaId = 10L;
        Consentimiento nuevoConsentimiento = new Consentimiento();
        nuevoConsentimiento.setCitaId(citaId);
        
        // No existe consentimiento previo para esta cita
        when(repository.findByCitaId(citaId)).thenReturn(Optional.empty());
        when(repository.save(nuevoConsentimiento)).thenReturn(nuevoConsentimiento);

        // When
        Consentimiento resultado = fichaService.registrarConsentimiento(nuevoConsentimiento);

        // Then
        assertNotNull(resultado);
        assertEquals(citaId, resultado.getCitaId());
        
        verify(repository, times(1)).findByCitaId(citaId);
        verify(repository, times(1)).save(nuevoConsentimiento);
    }

    @Test
    @DisplayName("Debería lanzar excepción si ya existe un consentimiento registrado para la misma cita")
    void registrarConsentimiento_ErrorDuplicado() {
        // Given
        Long citaId = 10L;
        Consentimiento nuevoConsentimiento = new Consentimiento();
        nuevoConsentimiento.setCitaId(citaId);

        Consentimiento consentimientoExistente = new Consentimiento();
        consentimientoExistente.setId(1L);
        consentimientoExistente.setCitaId(citaId);

        // Simulamos que ya existe un registro
        when(repository.findByCitaId(citaId)).thenReturn(Optional.of(consentimientoExistente));

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            fichaService.registrarConsentimiento(nuevoConsentimiento);
        });

        assertTrue(exception.getMessage().contains("Ya existe un consentimiento registrado"));
        // Regla de negocio: Si ya existe, jamás debe persistirse el duplicado
        verify(repository, never()).save(any(Consentimiento.class));
    }

    // =========================================================================
    // 2. TESTS: obtenerPorCita
    // =========================================================================
    @Test
    @DisplayName("Debería retornar el consentimiento si existe para la cita consultada")
    void obtenerPorCita_Exitoso() {
        // Given
        Long citaId = 5L;
        Consentimiento consentimientoSimulado = new Consentimiento();
        consentimientoSimulado.setCitaId(citaId);

        when(repository.findByCitaId(citaId)).thenReturn(Optional.of(consentimientoSimulado));

        // When
        Consentimiento resultado = fichaService.obtenerPorCita(citaId); // Verifica si se llama obtenerPorCita en tu código

        // Then
        assertNotNull(resultado);
        assertEquals(citaId, resultado.getCitaId());
        verify(repository, times(1)).findByCitaId(citaId);
    }

    @Test
    @DisplayName("Debería lanzar excepción si no se encuentra la ficha médica por la cita")
    void obtenerPorCita_NoEncontrado() {
        // Given
        Long citaId = 99L;
        when(repository.findByCitaId(citaId)).thenReturn(Optional.empty());

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            fichaService.obtenerPorCita(citaId);
        });

        assertTrue(exception.getMessage().contains("Ficha médica no encontrada para la cita"));
    }

    // =========================================================================
    // 3. TEST: obtenerTodas
    // =========================================================================
    @Test
    @DisplayName("Debería retornar la lista de todos los consentimientos")
    void obtenerTodasTest() {
        // Given
        List<Consentimiento> lista = List.of(new Consentimiento(), new Consentimiento());
        when(repository.findAll()).thenReturn(lista);

        // When
        List<Consentimiento> resultado = fichaService.obtenerTodas();

        // Then
        assertNotNull(resultado);
        assertEquals(2, resultado.size());
        verify(repository, times(1)).findAll();
    }

    // =========================================================================
    // 4. TESTS: eliminarConsentimiento
    // =========================================================================
    @Test
    @DisplayName("Debería eliminar el consentimiento si el ID existe en el sistema")
    void eliminarConsentimiento_Exitoso() {
        // Given
        Long idEliminar = 1L;
        when(repository.existsById(idEliminar)).thenReturn(true);
        doNothing().when(repository).deleteById(idEliminar); // doNothing se usa para métodos void

        // When
        assertDoesNotThrow(() -> fichaService.eliminarConsentimiento(idEliminar));

        // Then
        verify(repository, times(1)).existsById(idEliminar);
        verify(repository, times(1)).deleteById(idEliminar);
    }

    @Test
    @DisplayName("Debería lanzar excepción al intentar eliminar un ID que no existe")
    void eliminarConsentimiento_NoExiste() {
        // Given
        Long idEliminar = 999L;
        when(repository.existsById(idEliminar)).thenReturn(false);

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            fichaService.eliminarConsentimiento(idEliminar);
        });

        assertTrue(exception.getMessage().contains("No se puede eliminar: El registro médico no existe"));
        // Si no existe, no se debe intentar llamar a deleteById
        verify(repository, never()).deleteById(anyLong());
    }
}
