package bm.cartera.service.test;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import bm.cartera.Service.CarteraService;
import bm.cartera.model.Cartera;
import bm.cartera.repository.CarteraRepository;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CarteraServiceTest {

    @Mock
    private CarteraRepository carteraRepo;

    @InjectMocks
    private CarteraService carteraService;

    private Long runTatuador;
    private Cartera carteraEsperada;

    @BeforeEach
    void setUp() {
        runTatuador = 12345678L;
        
        carteraEsperada = new Cartera();
        carteraEsperada.setIdCartera(1L);
        carteraEsperada.setRunTatuador(runTatuador);
        carteraEsperada.setSaldoTotal(0);
    }

    @Test
    void crearNuevaCartera_DeberiaGuardarYRetornarCarteraInicializada() {
        // Arrange
        when(carteraRepo.save(any(Cartera.class))).thenReturn(carteraEsperada);

        // Act
        Cartera resultado = carteraService.crearNuevaCartera(runTatuador);

        // Assert
        assertNotNull(resultado);
        assertEquals(runTatuador, resultado.getRunTatuador());
        assertEquals(0, resultado.getSaldoTotal());
        
        // Verifica que el repositorio interactuó exactamente una vez con un objeto Cartera
        verify(carteraRepo, times(1)).save(any(Cartera.class));
    }

    @Test
    void consultarSaldo_DeberiaRetornarElSaldo_CuandoLaCarteraExiste() {
        // Arrange
        carteraEsperada.setSaldoTotal(50000); // Simulamos que ya tiene dinero
        when(carteraRepo.findByRunTatuador(runTatuador)).thenReturn(Optional.of(carteraEsperada));

        // Act
        Integer saldo = carteraService.consultarSaldo(runTatuador);

        // Assert
        assertNotNull(saldo);
        assertEquals(50000, saldo);
        verify(carteraRepo, times(1)).findByRunTatuador(runTatuador);
    }

    @Test
    void consultarSaldo_DeberiaRetornarCero_CuandoLaCarteraNoExiste() {
        // Arrange
        when(carteraRepo.findByRunTatuador(runTatuador)).thenReturn(Optional.empty());

        // Act
        Integer saldo = carteraService.consultarSaldo(runTatuador);

        // Assert
        assertNotNull(saldo);
        assertEquals(0, saldo); // Verifica el comportamiento del .orElse(0)
        verify(carteraRepo, times(1)).findByRunTatuador(runTatuador);
    }
}