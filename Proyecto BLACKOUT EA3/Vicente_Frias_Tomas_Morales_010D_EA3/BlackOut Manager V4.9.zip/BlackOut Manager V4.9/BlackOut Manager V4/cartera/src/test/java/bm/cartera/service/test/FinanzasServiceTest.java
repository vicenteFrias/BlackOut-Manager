package bm.cartera.service.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import bm.cartera.Service.FinanzasService;
import bm.cartera.dto.GastoRequestDTO;
import bm.cartera.model.Cartera;
import bm.cartera.model.Gastos;
import bm.cartera.model.Ingresos;
import bm.cartera.repository.CarteraRepository;
import bm.cartera.repository.GastosRepository;
import bm.cartera.repository.IngresosRepository;

@ExtendWith(MockitoExtension.class)
class FinanzasServiceTest {

    @Mock
    private IngresosRepository ingresosRepo;
    @Mock
    private GastosRepository gastosRepo;
    @Mock
    private CarteraRepository carteraRepo;

    @InjectMocks
    private FinanzasService finanzasService;

    private Long runTatuador;
    private Cartera carteraMock;

    @BeforeEach
    void setUp() {
        runTatuador = 12345678L;
        
        carteraMock = new Cartera();
        carteraMock.setIdCartera(1L);
        carteraMock.setRunTatuador(runTatuador);
        carteraMock.setSaldoTotal(20000); // Saldo inicial para pruebas genéricas
    }

    // ==========================================
    // TESTS PARA registrarTatuaje
    // ==========================================

    @Test
    void registrarTatuaje_DeberiaCalcularPrecioCorrectamenteYActualizarSaldo() {
        // Arrange
        double ht = 2.5; 
        int fTam = 2;    
        String desc = "Tatuaje Realismo";
        Long idCita = 99L;
        
        // CI = 12000, VHH = 6000, CC = 6000
        // pfCalculado = 12000 + (2.5 * 6000 * 2) + 6000 = 12000 + 30000 + 6000 = 48000
        int precioEsperado = 48000; 
        int saldoInicial = carteraMock.getSaldoTotal(); // 20000

        when(carteraRepo.findByRunTatuador(runTatuador)).thenReturn(Optional.of(carteraMock));
        
        // Mocking del guardado para retornar la misma entidad estructurada
        when(carteraRepo.save(any(Cartera.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(ingresosRepo.save(any(Ingresos.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        Ingresos resultado = finanzasService.registrarTatuaje(runTatuador, ht, fTam, desc, idCita);

        // Assert
        assertNotNull(resultado);
        assertEquals(precioEsperado, resultado.getMonto());
        assertEquals(desc, resultado.getDescripcion());
        assertEquals(idCita, resultado.getIdCita());
        assertEquals("TRANSFERENCIA/EFECTIVO", resultado.getMetodoPago());
        
        // Verificar que el saldo de la cartera aumentó correctamente
        assertEquals(saldoInicial + precioEsperado, carteraMock.getSaldoTotal());
        
        verify(carteraRepo, times(1)).save(carteraMock);
        verify(ingresosRepo, times(1)).save(any(Ingresos.class));
    }

    @Test
    void registrarTatuaje_DeberiaLanzarException_CuandoCarteraNoExiste() {
        // Arrange
        when(carteraRepo.findByRunTatuador(runTatuador)).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            finanzasService.registrarTatuaje(runTatuador, 2.0, 1, "test", 1L);
        });

        assertEquals("Cartera no encontrada para RUN: " + runTatuador, exception.getMessage());
        verify(carteraRepo, never()).save(any(Cartera.class));
        verify(ingresosRepo, never()).save(any(Ingresos.class));
    }

    // ==========================================
    // TESTS PARA registrarGasto
    // ==========================================

    @Test
    void registrarGasto_DeberiaRestarSaldoYGuardarGasto_CuandoSaldoEsSuficiente() {
        // Arrange
        // Simulamos un DTO usando un objeto simulado o clase real si la tienes armada
        GastoRequestDTO dto = new GastoRequestDTO(); 
        dto.setMonto(5000);
        dto.setCategoria("Insumos");
        dto.setDescripcion("Agujas 3RL");

        carteraMock.setSaldoTotal(15000); // Saldo suficiente
        int saldoInicial = carteraMock.getSaldoTotal();

        when(carteraRepo.findByRunTatuador(runTatuador)).thenReturn(Optional.of(carteraMock));
        when(carteraRepo.save(any(Cartera.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(gastosRepo.save(any(Gastos.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        Gastos resultado = finanzasService.registrarGasto(runTatuador, dto);

        // Assert
        assertNotNull(resultado);
        assertEquals(5000, resultado.getMontoGasto());
        assertEquals("Insumos", resultado.getCategoria());
        assertEquals(saldoInicial - dto.getMonto(), carteraMock.getSaldoTotal());

        verify(carteraRepo, times(1)).save(carteraMock);
        verify(gastosRepo, times(1)).save(any(Gastos.class));
    }

    @Test
    void registrarGasto_DeberiaLanzarException_CuandoSaldoEsInsuficiente() {
        // Arrange
        GastoRequestDTO dto = new GastoRequestDTO();
        dto.setMonto(30000); // Mayor que los 20000 de la cartera mock

        when(carteraRepo.findByRunTatuador(runTatuador)).thenReturn(Optional.of(carteraMock));

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            finanzasService.registrarGasto(runTatuador, dto);
        });

        assertEquals("Saldo insuficiente en la cartera del tatuador.", exception.getMessage());
        verify(carteraRepo, never()).save(any(Cartera.class));
        verify(gastosRepo, never()).save(any(Gastos.class));
    }

    // ==========================================
    // TESTS PARA METODOS DE CONSULTA
    // ==========================================

    @Test
    void calcularIngresosEnRango_DeberiaRetornarSuma_CuandoExistenRegistros() {
        // Arrange
        LocalDateTime inicio = LocalDateTime.now().minusDays(7);
        LocalDateTime fin = LocalDateTime.now();
        when(ingresosRepo.sumarIngresosPorRango(runTatuador, inicio, fin)).thenReturn(150000);

        // Act
        Integer total = finanzasService.calcularIngresosEnRango(runTatuador, inicio, fin);

        // Assert
        assertEquals(150000, total);
    }

    @Test
    void calcularIngresosEnRango_DeberiaRetornarCero_CuandoRepoRetornaNull() {
        // Arrange
        LocalDateTime inicio = LocalDateTime.now().minusDays(7);
        LocalDateTime fin = LocalDateTime.now();
        when(ingresosRepo.sumarIngresosPorRango(runTatuador, inicio, fin)).thenReturn(null);

        // Act
        Integer total = finanzasService.calcularIngresosEnRango(runTatuador, inicio, fin);

        // Assert
        assertEquals(0, total); // Verifica que la lógica ternaria maneje bien el null
    }

    @Test
    void listarIngresosEnRango_DeberiaRetornarListaDeIngresos() {
        // Arrange
        LocalDateTime inicio = LocalDateTime.now().minusDays(5);
        LocalDateTime fin = LocalDateTime.now();
        List<Ingresos> mockLista = Collections.singletonList(new Ingresos());
        
        when(ingresosRepo.findByCarteraRunTatuadorAndFechaBetween(runTatuador, inicio, fin))
                .thenReturn(mockLista);

        // Act
        List<Ingresos> resultado = finanzasService.listarIngresosEnRango(runTatuador, inicio, fin);

        // Assert
        assertFalse(resultado.isEmpty());
        assertEquals(1, resultado.size());
    }

    @Test
    void obtenerTotalGastadoPorCategoria_DeberiaRetornarMontoAcumulado() {
        // Arrange
        String categoria = "Arriendo";
        when(gastosRepo.sumarMontoPorCategoria(runTatuador, categoria)).thenReturn(250000);

        // Act
        Integer total = finanzasService.obtenerTotalGastadoPorCategoria(runTatuador, categoria);

        // Assert
        assertEquals(250000, total);
    }
}
