package bm.cartera.repository;

import bm.cartera.model.Ingresos;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface IngresosRepository extends JpaRepository<Ingresos, Long> {

    // Opción A: Obtener la lista de todos los ingresos en ese rango
    List<Ingresos> findByCarteraRunTatuadorAndFechaBetween(Long run, LocalDateTime inicio, LocalDateTime fin);

    // Opción B: Obtener directamente la SUMA de los ingresos en ese rango
    @Query("SELECT SUM(i.monto) FROM Ingresos i WHERE i.cartera.runTatuador = :run AND i.fecha BETWEEN :inicio AND :fin")
    Integer sumarIngresosPorRango(@Param("run") Long run, @Param("inicio") LocalDateTime inicio, @Param("fin") LocalDateTime fin);
}

