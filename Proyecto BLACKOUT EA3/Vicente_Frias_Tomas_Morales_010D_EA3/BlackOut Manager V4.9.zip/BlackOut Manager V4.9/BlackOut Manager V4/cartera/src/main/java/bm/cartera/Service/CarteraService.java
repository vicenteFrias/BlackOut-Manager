package bm.cartera.Service;

import bm.cartera.model.Cartera;
import bm.cartera.repository.CarteraRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CarteraService {

    @Autowired private CarteraRepository carteraRepo;

    public Cartera crearNuevaCartera(Long runTatuador) {
        Cartera nueva = new Cartera();
        nueva.setRunTatuador(runTatuador);
        nueva.setSaldoTotal(0); // Empezamos en cero pesos
        return carteraRepo.save(nueva);
    }

    public Integer consultarSaldo(Long runTatuador) {
        return carteraRepo.findByRunTatuador(runTatuador)
                .map(Cartera::getSaldoTotal)
                .orElse(0);
    }
}