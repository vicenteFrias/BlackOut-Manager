package bm.cartera.Service;

import bm.cartera.dto.GastoRequestDTO;
import bm.cartera.model.*;
import bm.cartera.repository.*;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class FinanzasService {

    @Autowired private IngresosRepository ingresosRepo;
    @Autowired private GastosRepository gastosRepo;
    @Autowired private CarteraRepository carteraRepo;

    private static final int CI = 12000;  // Costo Insumos
    private static final int VHH = 6000;  // Valor Hora Hombre
    private static final int CC = 6000;   // Costos Críticos

    @Transactional
    public Ingresos registrarTatuaje(Long run, double ht, int fTam, String desc, Long idCita) {
        double pfCalculado = CI + (ht * VHH * fTam) + CC;
        int precioFinal = (int) Math.ceil(pfCalculado);

        Cartera cartera = obtenerCartera(run);

        Ingresos ingreso = new Ingresos();
        ingreso.setMonto(precioFinal);
        ingreso.setDescripcion(desc);
        ingreso.setIdCita(idCita);
        ingreso.setMetodoPago("TRANSFERENCIA/EFECTIVO"); // Valor por defecto para cumplir con @NotBlank
        ingreso.setCartera(cartera);

        // Actualizar saldo
        cartera.setSaldoTotal(cartera.getSaldoTotal() + precioFinal);
    
        carteraRepo.save(cartera);
        return ingresosRepo.save(ingreso);
    }

    @Transactional
    public Gastos registrarGasto(Long run, GastoRequestDTO dto) {
        Cartera cartera = obtenerCartera(run);

        if (cartera.getSaldoTotal() < dto.getMonto()) {
            throw new RuntimeException("Saldo insuficiente en la cartera del tatuador.");
        }

        Gastos gasto = new Gastos();
        gasto.setMontoGasto(dto.getMonto());
        gasto.setCategoria(dto.getCategoria());
        gasto.setDescripcion(dto.getDescripcion());
        gasto.setCartera(cartera);

        cartera.setSaldoTotal(cartera.getSaldoTotal() - dto.getMonto());
        carteraRepo.save(cartera);
        return gastosRepo.save(gasto);
    }

    private Cartera obtenerCartera(Long run) {
        return carteraRepo.findByRunTatuador(run)
            .orElseThrow(() -> new RuntimeException("Cartera no encontrada para RUN: " + run));
    }

    public Integer calcularIngresosEnRango(Long run, LocalDateTime inicio, LocalDateTime fin) {
        Integer total = ingresosRepo.sumarIngresosPorRango(run, inicio, fin);
        return (total != null) ? total : 0;
    }

    public List<Ingresos> listarIngresosEnRango(Long run, LocalDateTime inicio, LocalDateTime fin) {
        return ingresosRepo.findByCarteraRunTatuadorAndFechaBetween(run, inicio, fin);
    }

    public Integer obtenerTotalGastadoPorCategoria(Long runTatuador, String categoria) {
        return gastosRepo.sumarMontoPorCategoria(runTatuador, categoria);
    }
}