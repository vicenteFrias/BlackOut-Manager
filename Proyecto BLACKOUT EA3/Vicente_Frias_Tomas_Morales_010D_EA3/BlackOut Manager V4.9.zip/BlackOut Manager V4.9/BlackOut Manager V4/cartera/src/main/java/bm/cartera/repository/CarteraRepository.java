package bm.cartera.repository;

import bm.cartera.model.Cartera;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface CarteraRepository extends JpaRepository<Cartera, Long> {
    // Buscamos la cartera por el RUN del tatuador
    Optional<Cartera> findByRunTatuador(Long runTatuador);
}