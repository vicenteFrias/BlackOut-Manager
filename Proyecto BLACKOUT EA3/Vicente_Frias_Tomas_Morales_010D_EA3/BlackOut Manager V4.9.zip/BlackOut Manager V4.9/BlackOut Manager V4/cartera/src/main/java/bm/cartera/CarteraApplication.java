package bm.cartera;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
public class CarteraApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarteraApplication.class, args);
	}

}
