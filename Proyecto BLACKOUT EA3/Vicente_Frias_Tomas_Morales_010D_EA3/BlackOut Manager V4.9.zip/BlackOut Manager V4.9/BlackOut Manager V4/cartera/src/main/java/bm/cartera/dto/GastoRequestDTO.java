package bm.cartera.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class GastoRequestDTO {
    @NotNull(message = "El monto es obligatorio")
    @Positive(message = "El monto debe ser mayor a cero")
    private Integer monto;

    @NotBlank(message = "La categoría es obligatoria (Insumos, Arriendo, etc.)")
    private String categoria;

    private String descripcion;
}