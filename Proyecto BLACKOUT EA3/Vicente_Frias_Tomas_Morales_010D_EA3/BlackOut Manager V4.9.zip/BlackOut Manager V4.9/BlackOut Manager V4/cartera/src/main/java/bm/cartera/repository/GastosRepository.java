package bm.cartera.repository;

import bm.cartera.model.Gastos;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface GastosRepository extends JpaRepository<Gastos, Long> {

    // 1. Buscar todos los registros de una categoría específica
    List<Gastos> findByCategoriaIgnoreCase(String categoria);

    // 2. Sumar el monto total gastado en una categoría para un tatuador específico
    @Query("SELECT SUM(g.montoGasto) FROM Gastos g WHERE g.cartera.runTatuador = :run AND UPPER(g.categoria) = UPPER(:cat)")
    Integer sumarMontoPorCategoria(@Param("run") Long runTatuador, @Param("cat") String categoria);

    //reporte mensual por categoria
    @Query("SELECT SUM(g.montoGasto) FROM Gastos g WHERE g.cartera.runTatuador = :run " +
       "AND UPPER(g.categoria) = UPPER(:cat) AND g.fechaGasto BETWEEN :inicio AND :fin")
    Integer sumarMontoPorCategoriaYRango(@Param("run") Long run, 
                                     @Param("cat") String cat, 
                                     @Param("inicio") LocalDateTime inicio, 
                                     @Param("fin") LocalDateTime fin);
}