package bm.cartera.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

@Data
public class IngresoRequestDTO {

    @Positive(message = "Las horas trabajadas deben ser mayores a cero")
    private double horasTotales;

    @Min(value = 1, message = "El factor de tamaño mínimo es 1")
    private int factorTamano;

    @NotBlank(message = "La descripción de la sesión es obligatoria")
    private String descripcion;

    @NotNull(message = "El ID de la cita es obligatorio para la trazabilidad")
    private Long idCita;
}