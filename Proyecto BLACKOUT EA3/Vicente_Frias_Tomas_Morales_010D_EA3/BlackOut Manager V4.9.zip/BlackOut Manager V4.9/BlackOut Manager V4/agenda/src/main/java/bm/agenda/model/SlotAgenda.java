package bm.agenda.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.v3.oas.annotations.media.Schema;

@Entity
@Table(name = "agenda")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SlotAgenda {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(accessMode = Schema.AccessMode.READ_ONLY, description = "ID autoincremental generado por la BD")
    private Long id;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime inicio;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime fin;
    
    private String titulo; // Ej: Tatuaje "nombre persona" / Gimnasio etc
    private String tipo;   // "TATUAJE" o "PERSONAL"

    // Este campo vincula la agenda con la cita. Para actividades personales será null.
    private Long citaId; 
}