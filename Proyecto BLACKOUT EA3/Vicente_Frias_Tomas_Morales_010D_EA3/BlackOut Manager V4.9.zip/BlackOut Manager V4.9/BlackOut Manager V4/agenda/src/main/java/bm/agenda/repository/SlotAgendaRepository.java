package bm.agenda.repository;

import bm.agenda.model.SlotAgenda;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface SlotAgendaRepository extends JpaRepository<SlotAgenda, Long> {
    
    List<SlotAgenda> findByInicioBetweenOrderByInicioAsc(LocalDateTime start, LocalDateTime end);

    List<SlotAgenda> findByTipo(String tipo);

    List<SlotAgenda> findByTituloContainingIgnoreCase(String titulo);

    Optional<SlotAgenda> findByCitaId(Long citaId);

    @Modifying
    @Transactional
    @Query("DELETE FROM SlotAgenda s WHERE s.citaId = ?1")
    void deleteByCitaId(Long citaId);

    /**
     * Valida si existe CUALQUIER actividad en ese rango.
     */
    @Query("SELECT COUNT(s) > 0 FROM SlotAgenda s WHERE " +
           "(s.inicio < :fin AND s.fin > :inicio)")
    boolean existeSolapamientoGeneral(@Param("inicio") LocalDateTime inicio, @Param("fin") LocalDateTime fin);

    /**
     * actividades personales no choquen con tatuajes, 
     * pero quizás sí entre ellas.
     */
    @Query("SELECT COUNT(s) > 0 FROM SlotAgenda s WHERE s.tipo = :tipo AND " +
           "(s.inicio < :fin AND s.fin > :inicio)")
    boolean existeSolapamientoPorTipo(@Param("tipo") String tipo, 
                                      @Param("inicio") LocalDateTime inicio, 
                                      @Param("fin") LocalDateTime fin);
}