package bm.agenda.service;

import bm.agenda.model.SlotAgenda;
import bm.agenda.repository.SlotAgendaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class AgendaService {

    @Autowired
    private SlotAgendaRepository repository;
    
    public boolean verificarDisponibilidadTotal(LocalDateTime inicio, LocalDateTime fin) {
        return repository.existeSolapamientoGeneral(inicio, fin);
    }

    @Transactional
    public SlotAgenda guardarOActualizar(SlotAgenda nuevoSlot) {
        if (nuevoSlot.getCitaId() != null) {
            return repository.findByCitaId(nuevoSlot.getCitaId())
                .map(slotExistente -> {
                    slotExistente.setInicio(nuevoSlot.getInicio());
                    slotExistente.setFin(nuevoSlot.getFin());
                    slotExistente.setTitulo(nuevoSlot.getTitulo());
                    slotExistente.setTipo(nuevoSlot.getTipo());
                    return repository.save(slotExistente);
                })
                .orElseGet(() -> repository.save(nuevoSlot));
        }
        return repository.save(nuevoSlot);
    }

    public List<SlotAgenda> obtenerAgendaDelDia(LocalDateTime fecha) {
        LocalDateTime inicio = fecha.withHour(0).withMinute(0).withSecond(0);
        LocalDateTime fin = fecha.withHour(23).withMinute(59).withSecond(59);
        return repository.findByInicioBetweenOrderByInicioAsc(inicio, fin);
    }

    @Transactional
    public SlotAgenda guardarActividadPersonal(SlotAgenda personal) {
        personal.setTipo("PERSONAL");
        personal.setCitaId(null);

        // Validamos: ¿Hay algún tatuaje en este horario?
        boolean chocaConTatuaje = repository.existeSolapamientoPorTipo("TATUAJE", 
                                    personal.getInicio(), personal.getFin());

        if (chocaConTatuaje) {
            throw new RuntimeException("No puedes agendar esto: Tienes un tatuaje programado en este horario.");
        }

        return repository.save(personal);
    }

    public List<SlotAgenda> buscarPorTitulo(String titulo) {
        return repository.findByTituloContainingIgnoreCase(titulo);
    }

    @Transactional
    public void eliminarPorCita(Long citaId) {
        repository.deleteByCitaId(citaId);
    }

    public void eliminarManual(Long id) {
        repository.deleteById(id);
    }

}