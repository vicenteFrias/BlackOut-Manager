package bm.agenda.config;

public class WebClientConfig {

}
