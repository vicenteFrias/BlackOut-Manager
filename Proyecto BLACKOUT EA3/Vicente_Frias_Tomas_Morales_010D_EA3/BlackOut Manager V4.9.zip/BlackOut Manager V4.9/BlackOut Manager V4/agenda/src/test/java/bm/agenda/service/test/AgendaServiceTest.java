package bm.agenda.service.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import bm.agenda.model.SlotAgenda;
import bm.agenda.repository.SlotAgendaRepository;
import bm.agenda.service.AgendaService;

@ExtendWith(MockitoExtension.class)
class AgendaServiceTest {

    @Mock
    private SlotAgendaRepository repository;

    @InjectMocks
    private AgendaService agendaService;

    private SlotAgenda slotMock;
    private LocalDateTime fechaInicio;
    private LocalDateTime fechaFin;

    @BeforeEach
    void setUp() {
        fechaInicio = LocalDateTime.of(2026, 6, 16, 10, 0);
        fechaFin = LocalDateTime.of(2026, 6, 16, 13, 0);

        slotMock = new SlotAgenda();
        slotMock.setId(1L);
        slotMock.setCitaId(100L);
        slotMock.setInicio(fechaInicio);
        slotMock.setFin(fechaFin);
        slotMock.setTitulo("Sesión Blackwork");
        slotMock.setTipo("TATUAJE");
    }

    // ==========================================
    // verificarDisponibilidadTotal
    // ==========================================
    @Test
    void verificarDisponibilidadTotal_DeberiaRetornarTrue_CuandoExisteSolapamiento() {
        // Arrange
        when(repository.existeSolapamientoGeneral(fechaInicio, fechaFin)).thenReturn(true);

        // Act
        boolean resultado = agendaService.verificarDisponibilidadTotal(fechaInicio, fechaFin);

        // Assert
        assertTrue(resultado);
        verify(repository, times(1)).existeSolapamientoGeneral(fechaInicio, fechaFin);
    }

    // ==========================================
    // guardarOActualizar
    // ==========================================
    @Test
    void guardarOActualizar_DeberiaActualizarSlotExistente_CuandoCitaIdExiste() {
        // Arrange
        SlotAgenda slotExistente = new SlotAgenda();
        slotExistente.setId(1L);
        slotExistente.setCitaId(100L);
        slotExistente.setTitulo("Título Viejo");

        when(repository.findByCitaId(100L)).thenReturn(Optional.of(slotExistente));
        when(repository.save(slotExistente)).thenReturn(slotExistente);

        // Act
        SlotAgenda resultado = agendaService.guardarOActualizar(slotMock);

        // Assert
        assertNotNull(resultado);
        assertEquals("Sesión Blackwork", slotExistente.getTitulo()); // Se debió mapear el nuevo título
        verify(repository, times(1)).findByCitaId(100L);
        verify(repository, times(1)).save(slotExistente);
    }

    @Test
    void guardarOActualizar_DeberiaCrearNuevoSlot_CuandoCitaIdNoExisteEnBD() {
        // Arrange
        when(repository.findByCitaId(100L)).thenReturn(Optional.empty());
        when(repository.save(slotMock)).thenReturn(slotMock);

        // Act
        SlotAgenda resultado = agendaService.guardarOActualizar(slotMock);

        // Assert
        assertNotNull(resultado);
        verify(repository, times(1)).findByCitaId(100L);
        // Se llama en el .orElseGet y luego sale del if y ejecuta el return final externo
        verify(repository, atLeastOnce()).save(slotMock);
    }

    @Test
    void guardarOActualizar_DeberiaGuardarDirectamente_CuandoCitaIdEsNull() {
        // Arrange
        slotMock.setCitaId(null);
        when(repository.save(slotMock)).thenReturn(slotMock);

        // Act
        SlotAgenda resultado = agendaService.guardarOActualizar(slotMock);

        // Assert
        assertNotNull(resultado);
        verify(repository, never()).findByCitaId(any());
        verify(repository, times(1)).save(slotMock);
    }

    // ==========================================
    // obtenerAgendaDelDia
    // ==========================================
    @Test
    void obtenerAgendaDelDia_DeberiaCalcularRangoCorrectamenteYBuscar() {
        // Arrange
        LocalDateTime fechaConsulta = LocalDateTime.of(2026, 6, 16, 15, 30);
        LocalDateTime inicioEsperado = LocalDateTime.of(2026, 6, 16, 0, 0, 0);
        LocalDateTime finEsperado = LocalDateTime.of(2026, 6, 16, 23, 59, 59);

        List<SlotAgenda> listaMock = Collections.singletonList(slotMock);
        when(repository.findByInicioBetweenOrderByInicioAsc(inicioEsperado, finEsperado)).thenReturn(listaMock);

        // Act
        List<SlotAgenda> resultado = agendaService.obtenerAgendaDelDia(fechaConsulta);

        // Assert
        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        verify(repository, times(1)).findByInicioBetweenOrderByInicioAsc(inicioEsperado, finEsperado);
    }

    // ==========================================
    // guardarActividadPersonal
    // ==========================================
    @Test
    void guardarActividadPersonal_DeberiaGuardar_CuandoNoChocaConTatuaje() {
        // Arrange
        SlotAgenda actividadPersonal = new SlotAgenda();
        actividadPersonal.setInicio(fechaInicio);
        actividadPersonal.setFin(fechaFin);
        actividadPersonal.setTitulo("Almuerzo");

        when(repository.existeSolapamientoPorTipo("TATUAJE", fechaInicio, fechaFin)).thenReturn(false);
        when(repository.save(actividadPersonal)).thenReturn(actividadPersonal);

        // Act
        SlotAgenda resultado = agendaService.guardarActividadPersonal(actividadPersonal);

        // Assert
        assertNotNull(resultado);
        assertEquals("PERSONAL", resultado.getTipo());
        assertNull(resultado.getCitaId());
        verify(repository, times(1)).save(actividadPersonal);
    }

    @Test
    void guardarActividadPersonal_DeberiaLanzarException_CuandoChocaConTatuaje() {
        // Arrange
        SlotAgenda actividadPersonal = new SlotAgenda();
        actividadPersonal.setInicio(fechaInicio);
        actividadPersonal.setFin(fechaFin);

        when(repository.existeSolapamientoPorTipo("TATUAJE", fechaInicio, fechaFin)).thenReturn(true);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            agendaService.guardarActividadPersonal(actividadPersonal);
        });

        assertEquals("No puedes agendar esto: Tienes un tatuaje programado en este horario.", exception.getMessage());
        verify(repository, never()).save(any(SlotAgenda.class));
    }

    // ==========================================
    // buscarPorTitulo
    // ==========================================
    @Test
    void buscarPorTitulo_DeberiaLlamarAlRepositoryIgnoringCase() {
        // Arrange
        String tituloBuscar = "blackwork";
        when(repository.findByTituloContainingIgnoreCase(tituloBuscar)).thenReturn(Collections.singletonList(slotMock));

        // Act
        List<SlotAgenda> resultado = agendaService.buscarPorTitulo(tituloBuscar);

        // Assert
        assertFalse(resultado.isEmpty());
        verify(repository, times(1)).findByTituloContainingIgnoreCase(tituloBuscar);
    }

    // ==========================================
    // Métodos de Eliminación
    // ==========================================
    @Test
    void eliminarPorCita_DeberiaLlamarDeleteByCitaId() {
        // Act
        agendaService.eliminarPorCita(100L);

        // Assert
        verify(repository, times(1)).deleteByCitaId(100L);
    }

    @Test
    void eliminarManual_DeberiaLlamarDeleteById() {
        // Act
        agendaService.eliminarManual(1L);

        // Assert
        verify(repository, times(1)).deleteById(1L);
    }
}
