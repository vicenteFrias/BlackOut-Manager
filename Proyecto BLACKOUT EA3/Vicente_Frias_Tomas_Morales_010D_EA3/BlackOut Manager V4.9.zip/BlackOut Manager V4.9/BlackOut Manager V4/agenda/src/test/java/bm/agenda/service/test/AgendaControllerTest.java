package bm.agenda.service.test;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import bm.agenda.controller.AgendaController;
import bm.agenda.dto.SlotAgendaDTO;
import bm.agenda.model.SlotAgenda;
import bm.agenda.service.AgendaService;

@ExtendWith(MockitoExtension.class)
public class AgendaControllerTest {

    private MockMvc mockMvc;

    @Mock
    private AgendaService agendaService;

    @InjectMocks
    private AgendaController agendaController;

    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(agendaController).build();
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
    }

    @Test
    void validarDisponibilidad_DeberiaRetornarTrue() throws Exception {
        // Arrange
        when(agendaService.verificarDisponibilidadTotal(any(LocalDateTime.class), any(LocalDateTime.class)))
                .thenReturn(true);

        // Act & Assert
        mockMvc.perform(get("/api/v1/agenda/validar-disponibilidad")
                .param("inicio", "2027-06-21T10:00:00") // Formato ISO para el RequestParam
                .param("fin", "2027-06-21T11:00:00")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string("true"));
    }

    @Test
    void bloquear_DeberiaRetornarStatusCreatedYSloAgenda() throws Exception {
        // Arrange - Forzamos año 2027 para cumplir con @FutureOrPresent
        SlotAgendaDTO dto = new SlotAgendaDTO();
        dto.setInicio(LocalDateTime.of(2027, 6, 21, 14, 0));
        dto.setFin(LocalDateTime.of(2027, 6, 21, 15, 0));
        dto.setTitulo("Bloqueo Cita Tatuaje"); // Cumple con @Size(min=3)
        dto.setTipo("TATUAJE"); // Cumple exactamente con la Regex "TATUAJE|PERSONAL"
        dto.setCitaId(101L);

        SlotAgenda slotGuardado = new SlotAgenda();
        slotGuardado.setId(1L);
        slotGuardado.setInicio(dto.getInicio());
        slotGuardado.setFin(dto.getFin());
        slotGuardado.setTitulo("Bloqueo Cita Tatuaje");
        slotGuardado.setTipo("TATUAJE");
        slotGuardado.setCitaId(101L);

        when(agendaService.guardarOActualizar(any(SlotAgenda.class))).thenReturn(slotGuardado);

        // Act & Assert
        mockMvc.perform(post("/api/v1/agenda/bloquear")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isCreated()) // ¡Ahora sí devolverá 201 Created!
                .andExpect(jsonPath("$.id").value(1)) // Quitamos el "L" para evitar conflictos de tipo con JSON
                .andExpect(jsonPath("$.titulo").value("Bloqueo Cita Tatuaje"))
                .andExpect(jsonPath("$.tipo").value("TATUAJE"));
    }

    @Test
    void crearPersonal_DeberiaRetornarStatusCreatedYActividadPersonal() throws Exception {
        // Arrange - Año 2027 seguro
        SlotAgendaDTO dto = new SlotAgendaDTO();
        dto.setInicio(LocalDateTime.of(2027, 6, 21, 13, 0));
        dto.setFin(LocalDateTime.of(2027, 6, 21, 14, 0));
        dto.setTitulo("Almuerzo");
        dto.setTipo("PERSONAL"); // Cumple con la Regex

        SlotAgenda personalGuardado = new SlotAgenda();
        personalGuardado.setId(2L);
        personalGuardado.setInicio(dto.getInicio());
        personalGuardado.setFin(dto.getFin());
        personalGuardado.setTitulo("Almuerzo");
        personalGuardado.setTipo("PERSONAL");

        when(agendaService.guardarActividadPersonal(any(SlotAgenda.class))).thenReturn(personalGuardado);

        // Act & Assert
        mockMvc.perform(post("/api/v1/agenda/personal")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isCreated()) // 201 Created
                .andExpect(jsonPath("$.id").value(2))
                .andExpect(jsonPath("$.titulo").value("Almuerzo"))
                .andExpect(jsonPath("$.tipo").value("PERSONAL"));
    }
}
