package com.api.gateway.filter;
import java.nio.charset.StandardCharsets;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import reactor.core.publisher.Mono;
import org.springframework.cloud.gateway.filter.GatewayFilter;
@Component
public class AuthenticationFilter extends AbstractGatewayFilterFactory<AuthenticationFilter.Config>
{
    @Value("${jwt.secret}")
    private String secreto;
    public AuthenticationFilter()
    {
        super(Config.class);
    }
    public static class Config
    {
        //Configuracion adicional si fuera necesario
    }
    @Override
    public GatewayFilter apply(Config config)
    {
        return (exchange, chain) ->
        {
            String path = exchange.getRequest().getURI().getPath();
            // SI ES LA DOCUMENTACIÓN, PASA LIBRE (Para que cargue Swagger)
            if (path.contains("v3/api-docs") || path.contains("swagger-ui")) {
                return chain.filter(exchange);
            }
            // 1. Obtener la cabecera de forma segura
            String authHeader = exchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);

            // 2. Validar que exista y tenga el formato correcto
            if (authHeader == null || !authHeader.startsWith("Bearer "))
            {
                return onError(exchange, "Token faltante o formato invalido", HttpStatus.UNAUTHORIZED);
            }
            String token = authHeader.substring(7);
            try{
            // Esta es la sintaxis para versiones 0.10.x y 0.11.x
            Jwts.parserBuilder()
                .setSigningKey(Keys.hmacShaKeyFor(secreto.getBytes(StandardCharsets.UTF_8)))
                .build()
                .parseClaimsJws(token);
            } catch (Exception e)
            {
                return onError(exchange, "Token invalido o expirado", HttpStatus.UNAUTHORIZED);
            }
            return chain.filter(exchange);
        };
    }
    private Mono<Void> onError(ServerWebExchange exchange, String err, HttpStatus httpStatus)
    {
        exchange.getResponse().setStatusCode(httpStatus);
        // Opcional: podrias loguear el error 'err aqui'
        return exchange.getResponse().setComplete();
    }
}