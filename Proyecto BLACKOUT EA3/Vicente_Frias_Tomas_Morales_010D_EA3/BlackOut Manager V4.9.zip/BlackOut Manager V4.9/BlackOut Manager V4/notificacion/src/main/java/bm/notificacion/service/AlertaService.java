package bm.notificacion.service;

import bm.notificacion.model.AlertaNotificacion;
import bm.notificacion.model.EstadoEnvio;
import bm.notificacion.repository.AlertaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class AlertaService {

    @Autowired
    private AlertaRepository repository;

    @Transactional
    public AlertaNotificacion registrarNotificacion(AlertaNotificacion alerta) {
        alerta.setEstado(EstadoEnvio.PENDIENTE);
        AlertaNotificacion guardada = repository.save(alerta);
        
        // Ejecutamos la simulación de despacho inmediatamente
        simularEnvioDispositivo(guardada);
        
        return guardada;
    }

    private void simularEnvioDispositivo(AlertaNotificacion alerta) {
        // Simulación visual en la consola del servidor (No requiere APIs externas de pago)
        System.out.println("\n==================================================================");
        System.out.println("🔔 [SIMULADOR DE NOTIFICACIONES TATTOO] Disparando canal externo...");
        System.out.println("📱 DESTINATARIO: " + alerta.getContactoCliente());
        System.out.println("🆔 VÍNCULO CITA: #" + alerta.getCitaId());
        System.out.println("💬 MENSAJE COMPUESTO: \"" + alerta.getMensaje() + "\"");
        System.out.println("⚡ ESTADO: Procesando envío de paquetes virtuales...");
        System.out.println("✅ [ÉXITO] Notificación entregada correctamente vía simulación local.");
        System.out.println("==================================================================\n");

        // Actualizamos el estado tras el éxito de la simulación
        alerta.setEstado(EstadoEnvio.ENVIADO);
        repository.save(alerta);
    }

    public List<AlertaNotificacion> obtenerHistorialPorCliente(String contacto) {
        return repository.findByContactoClienteOrderByFechaRegistroDesc(contacto);
    }

    public List<AlertaNotificacion> obtenerTodas() {
        return repository.findAll();
    }
}