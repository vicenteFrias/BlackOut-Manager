package bm.notificacion.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AlertaRequestDTO {

    @NotNull(message = "Debe especificar el ID de la cita")
    private Long citaId;

    @NotBlank(message = "Debe ingresar el contacto de destino")
    private String contactoCliente;

    @NotBlank(message = "Debe redactar el mensaje de la alerta")
    private String mensaje;
}