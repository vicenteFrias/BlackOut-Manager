package bm.notificacion.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import org.hibernate.annotations.CreationTimestamp;
import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.v3.oas.annotations.media.Schema;

@Entity
@Table(name = "alertas_notificaciones")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AlertaNotificacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(accessMode = Schema.AccessMode.READ_ONLY, description = "ID autoincremental generado por la BD")
    private Long id;

    @NotNull(message = "El ID de la cita es obligatorio")
    private Long citaId; // Enlace lógico con MS Citas

    @NotBlank(message = "El contacto del cliente (WhatsApp/Email) no puede estar vacío")
    private String contactoCliente;

    @NotBlank(message = "El cuerpo del mensaje es obligatorio")
    @Column(length = 1000)
    private String mensaje;

    @Enumerated(EnumType.STRING)
    private EstadoEnvio estado; // PENDIENTE, ENVIADO, FALLIDO

    @CreationTimestamp
    @Column(updatable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime fechaRegistro;
}