package bm.notificacion.controller;

import bm.notificacion.dto.AlertaRequestDTO;
import bm.notificacion.model.AlertaNotificacion;
import bm.notificacion.service.AlertaService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1/notificaciones")
public class AlertaController {

    @Autowired
    private AlertaService alertaService;

    /**
     * Encola y simula el envío de una nueva alerta de texto hacia el cliente
     */
    @PostMapping("/enviar")
    public ResponseEntity<AlertaNotificacion> enviarAlerta(@Valid @RequestBody AlertaRequestDTO dto) {
        AlertaNotificacion nuevaAlerta = new AlertaNotificacion();
        nuevaAlerta.setCitaId(dto.getCitaId());
        nuevaAlerta.setContactoCliente(dto.getContactoCliente());
        nuevaAlerta.setMensaje(dto.getMensaje());

        AlertaNotificacion procesada = alertaService.registrarNotificacion(nuevaAlerta);
        return ResponseEntity.status(HttpStatus.CREATED).body(procesada);
    }

    /**
     * Recupera el historial transaccional de alertas dirigidas a un contacto
     */
    @GetMapping("/historial")
    public ResponseEntity<List<AlertaNotificacion>> consultarHistorial(@RequestParam String contacto) {
        List<AlertaNotificacion> historial = alertaService.obtenerHistorialPorCliente(contacto);
        return historial.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(historial);
    }

    /**
     * Listar todas las notificaciones del sistema global (Para auditorías del Profesor)
     */
    @GetMapping
    public ResponseEntity<List<AlertaNotificacion>> listarTodo() {
        List<AlertaNotificacion> todas = alertaService.obtenerTodas();
        return todas.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(todas);
    }
}