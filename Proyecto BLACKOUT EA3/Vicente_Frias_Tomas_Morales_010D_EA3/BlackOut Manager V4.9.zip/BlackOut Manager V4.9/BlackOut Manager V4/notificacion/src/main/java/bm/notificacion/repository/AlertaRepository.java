package bm.notificacion.repository;

import bm.notificacion.model.AlertaNotificacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface AlertaRepository extends JpaRepository<AlertaNotificacion, Long> {
    
    // Buscar historial de alertas enviadas a un canal de contacto específico
    List<AlertaNotificacion> findByContactoClienteOrderByFechaRegistroDesc(String contactoCliente);
}