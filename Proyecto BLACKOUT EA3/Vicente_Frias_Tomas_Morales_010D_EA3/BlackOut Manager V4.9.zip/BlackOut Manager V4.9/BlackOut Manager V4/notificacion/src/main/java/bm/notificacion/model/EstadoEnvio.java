package bm.notificacion.model;

public enum EstadoEnvio {
    PENDIENTE,
    ENVIADO,
    FALLIDO
}