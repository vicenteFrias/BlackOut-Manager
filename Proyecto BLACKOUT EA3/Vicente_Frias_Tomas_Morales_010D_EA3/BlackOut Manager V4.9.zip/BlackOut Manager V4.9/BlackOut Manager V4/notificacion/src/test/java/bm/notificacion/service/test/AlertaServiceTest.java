package bm.notificacion.service.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import bm.notificacion.model.AlertaNotificacion;
import bm.notificacion.model.EstadoEnvio;
import bm.notificacion.repository.AlertaRepository;
import bm.notificacion.service.AlertaService;

@ExtendWith(MockitoExtension.class)
public class AlertaServiceTest {

    @Mock
    private AlertaRepository repository; // Simula el repositorio inyectado con @Autowired

    @InjectMocks
    private AlertaService alertaService; // Instancia real del servicio con el mock de arriba integrado

    // ==========================================
    // 1. TEST: registrarNotificacion
    // ==========================================
    @Test
    @DisplayName("Debería registrar una notificación, pasar por la simulación y actualizar a ENVIADO")
    void registrarNotificacionTest() {
        // 1. Preparar el escenario (Given)
        AlertaNotificacion alertaEntrada = new AlertaNotificacion();
        alertaEntrada.setContactoCliente("+56912345678");
        alertaEntrada.setCitaId(101L);
        alertaEntrada.setMensaje("Tu cita de tatuaje está confirmada.");

        // Simulamos la primera respuesta del save (cuando el estado pasa a PENDIENTE)
        when(repository.save(any(AlertaNotificacion.class))).thenAnswer(invocation -> {
            AlertaNotificacion guardada = invocation.getArgument(0);
            // Si el método simularEnvioDispositivo aún no corre, debería estar en PENDIENTE en el primer save
            return guardada;
        });

        // 2. Ejecutar la acción (When)
        AlertaNotificacion resultado = alertaService.registrarNotificacion(alertaEntrada);

        // 3. Aserciones (Then)
        assertNotNull(resultado);
        assertEquals("+56912345678", resultado.getContactoCliente());
        assertEquals(101L, resultado.getCitaId());
        
        // REGLA DE NEGOCIO CRÍTICA: Al finalizar el flujo de simulación, el método cambia el estado a ENVIADO
        // y vuelve a llamar a repository.save(). Por ende, el resultado final debe ser ENVIADO.
        assertEquals(EstadoEnvio.ENVIADO, resultado.getEstado(), "El estado final debería haber mutado a ENVIADO");

        // Verificamos que repository.save() se llamó exactamente 2 veces:
        // Una vez al inicio del método (como PENDIENTE) y otra al final de simularEnvioDispositivo (como ENVIADO)
        verify(repository, times(2)).save(any(AlertaNotificacion.class));
    }

    // ==========================================
    // 2. TEST: obtenerHistorialPorCliente
    // ==========================================
    @Test
    @DisplayName("Debería retornar el historial filtrado por el contacto de un cliente")
    void obtenerHistorialPorClienteTest() {
        // 1. Preparar el escenario (Given)
        String contactoBusqueda = "+56987654321";
        
        AlertaNotificacion a1 = new AlertaNotificacion();
        a1.setContactoCliente(contactoBusqueda);
        a1.setMensaje("Alerta 1");
        
        List<AlertaNotificacion> listaSimulada = List.of(a1);

        when(repository.findByContactoClienteOrderByFechaRegistroDesc(contactoBusqueda)).thenReturn(listaSimulada);

        // 2. Ejecutar la acción (When)
        List<AlertaNotificacion> resultado = alertaService.obtenerHistorialPorCliente(contactoBusqueda);

        // 3. Aserciones (Then)
        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        assertEquals(contactoBusqueda, resultado.get(0).getContactoCliente());

        verify(repository, times(1)).findByContactoClienteOrderByFechaRegistroDesc(contactoBusqueda);
    }

    // ==========================================
    // 3. TEST: obtenerTodas
    // ==========================================
    @Test
    @DisplayName("Debería retornar todas las alertas de notificación registradas")
    void obtenerTodasTest() {
        // 1. Preparar el escenario (Given)
        AlertaNotificacion a1 = new AlertaNotificacion();
        AlertaNotificacion a2 = new AlertaNotificacion();
        List<AlertaNotificacion> todasLasAlertas = List.of(a1, a2);

        when(repository.findAll()).thenReturn(todasLasAlertas);

        // 2. Ejecutar la acción (When)
        List<AlertaNotificacion> resultado = alertaService.obtenerTodas();

        // 3. Aserciones (Then)
        assertNotNull(resultado);
        assertEquals(2, resultado.size(), "Debería listar exactamente las 2 alertas");

        verify(repository, times(1)).findAll();
    }
}
