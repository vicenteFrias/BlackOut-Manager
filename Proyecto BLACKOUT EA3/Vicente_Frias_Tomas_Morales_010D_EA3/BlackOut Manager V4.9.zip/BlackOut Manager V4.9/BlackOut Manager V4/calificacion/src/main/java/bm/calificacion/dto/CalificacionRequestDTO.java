package bm.calificacion.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CalificacionRequestDTO {

    @NotNull(message = "El ID de la cita no puede ser nulo")
    private Long citaId;

    @NotNull(message = "El ID del tatuador no puede ser nulo")
    private Long tatuadorId;

    @NotNull(message = "Debe ingresar una puntuación")
    @Min(value = 1, message = "El puntaje mínimo es 1")
    @Max(value = 5, message = "El puntaje máximo es 5")
    private Integer puntuacion;

    private String comentario;
}