package bm.calificacion.service;

import bm.calificacion.model.Calificacion;
import bm.calificacion.repository.CalificacionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class CalificacionService {

    private static final Logger log = LoggerFactory.getLogger(CalificacionService.class);

    @Autowired
    private CalificacionRepository repository;

    @Transactional
    public Calificacion registrarCalificacion(Calificacion calificacion) {
        // Regla de Negocio: No se puede calificar la misma cita de tatuaje dos veces
        repository.findByCitaId(calificacion.getCitaId()).ifPresent(c -> {
            log.error("Intento duplicado de calificación para la cita {}", calificacion.getCitaId());
            throw new RuntimeException("Esta cita ya ha sido calificada anteriormente.");
        });

        log.info("Registrando calificación de {} estrellas para el tatuador {}", 
                 calificacion.getPuntuacion(), calificacion.getTatuadorId());
        
        return repository.save(calificacion);
    }

    public List<Calificacion> listarPorTatuador(Long tatuadorId) {
        return repository.findByTatuadorId(tatuadorId);
    }

    // Calcula dinámicamente la nota promedio de un artista
    public double calcularPromedioTatuador(Long tatuadorId) {
        List<Calificacion> calificaciones = repository.findByTatuadorId(tatuadorId);
        if (calificaciones.isEmpty()) {
            return 0.0;
        }
        
        double suma = 0;
        for (Calificacion c : calificaciones) {
            suma += c.getPuntuacion();
        }
        
        return suma / calificaciones.size();
    }

    @Transactional
    public void eliminarCalificacion(Long id) {
        repository.deleteById(id);
    }
}