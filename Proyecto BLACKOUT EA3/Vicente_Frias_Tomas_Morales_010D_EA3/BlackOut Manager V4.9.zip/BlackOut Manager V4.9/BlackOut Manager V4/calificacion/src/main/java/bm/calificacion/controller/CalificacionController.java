package bm.calificacion.controller;

import bm.calificacion.dto.CalificacionRequestDTO;
import bm.calificacion.model.Calificacion;
import bm.calificacion.service.CalificacionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1/calificaciones")
public class CalificacionController {

    @Autowired
    private CalificacionService calificacionService;

    /**
     * El cliente envía su reseña después del tatuaje
     */
    @PostMapping
    public ResponseEntity<Calificacion> crear(@Valid @RequestBody CalificacionRequestDTO dto) {
        Calificacion calificacion = new Calificacion();
        calificacion.setCitaId(dto.getCitaId());
        calificacion.setTatuadorId(dto.getTatuadorId());
        calificacion.setPuntuacion(dto.getPuntuacion());
        calificacion.setComentario(dto.getComentario());

        Calificacion guardada = calificacionService.registrarCalificacion(calificacion);
        return ResponseEntity.status(HttpStatus.CREATED).body(guardada);
    }

    /**
     * Ver todas las reseñas que tiene un tatuador
     */
    @GetMapping("/tatuador/{id}")
    public ResponseEntity<List<Calificacion>> verResenasDeTatuador(@PathVariable Long id) {
        List<Calificacion> lista = calificacionService.listarPorTatuador(id);
        return lista.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(lista);
    }

    /**
     * Ver el rating (promedio de estrellas) de un tatuador
     */
    @GetMapping("/tatuador/{id}/promedio")
    public ResponseEntity<Map<String, Object>> verPromedioTatuador(@PathVariable Long id) {
        double promedio = calificacionService.calcularPromedioTatuador(id);
        
        Map<String, Object> response = new HashMap<>();
        response.put("tatuadorId", id);
        response.put("promedioEstrellas", promedio);
        
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> borrar(@PathVariable Long id) {
        calificacionService.eliminarCalificacion(id);
        return ResponseEntity.noContent().build();
    }
}