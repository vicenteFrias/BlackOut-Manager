package bm.calificacion.repository;

import bm.calificacion.model.Calificacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface CalificacionRepository extends JpaRepository<Calificacion, Long> {
    
    // Regla de Negocio: Saber si una cita ya fue calificada
    Optional<Calificacion> findByCitaId(Long citaId);

    // Obtener todo el historial de reseñas de un tatuador
    List<Calificacion> findByTatuadorId(Long tatuadorId);
}