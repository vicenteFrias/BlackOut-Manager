package bm.calificacion.service.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import bm.calificacion.model.Calificacion;
import bm.calificacion.repository.CalificacionRepository;
import bm.calificacion.service.CalificacionService;

@ExtendWith(MockitoExtension.class)
class CalificacionServiceTest {

    @Mock
    private CalificacionRepository repository;

    @InjectMocks
    private CalificacionService calificacionService;

    private Calificacion calificacionMock;
    private Long tatuadorId;
    private Long citaId;

    @BeforeEach
    void setUp() {
        tatuadorId = 12345678L;
        citaId = 99L;

        calificacionMock = new Calificacion();
        calificacionMock.setId(1L);
        calificacionMock.setCitaId(citaId);
        calificacionMock.setTatuadorId(tatuadorId);
        calificacionMock.setPuntuacion(5); // 5 estrellas
    }

    // ==========================================
    // registrarCalificacion
    // ==========================================
    @Test
    void registrarCalificacion_DeberiaGuardarExitosamente_CuandoLaCitaNoHaSidoCalificada() {
        // Arrange
        // Simulamos que al buscar por idCita, no encuentra nada (está disponible para calificar)
        when(repository.findByCitaId(citaId)).thenReturn(Optional.empty());
        when(repository.save(any(Calificacion.class))).thenReturn(calificacionMock);

        // Act
        Calificacion resultado = calificacionService.registrarCalificacion(calificacionMock);

        // Assert
        assertNotNull(resultado);
        assertEquals(5, resultado.getPuntuacion());
        verify(repository, times(1)).findByCitaId(citaId);
        verify(repository, times(1)).save(calificacionMock);
    }

    @Test
    void registrarCalificacion_DeberiaLanzarException_CuandoLaCitaYaTieneCalificacion() {
        // Arrange
        // Simulamos que la cita YA posee una calificación registrada
        when(repository.findByCitaId(citaId)).thenReturn(Optional.of(calificacionMock));

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            calificacionService.registrarCalificacion(calificacionMock);
        });

        assertEquals("Esta cita ya ha sido calificada anteriormente.", exception.getMessage());
        
        // Verificamos que se corta el flujo y NUNCA se manda a guardar al repositorio
        verify(repository, times(1)).findByCitaId(citaId);
        verify(repository, never()).save(any(Calificacion.class));
    }

    // ==========================================
    // listarPorTatuador
    // ==========================================
    @Test
    void listarPorTatuador_DeberiaRetornarListaDeCalificaciones() {
        // Arrange
        List<Calificacion> lista = Collections.singletonList(calificacionMock);
        when(repository.findByTatuadorId(tatuadorId)).thenReturn(lista);

        // Act
        List<Calificacion> resultado = calificacionService.listarPorTatuador(tatuadorId);

        // Assert
        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        verify(repository, times(1)).findByTatuadorId(tatuadorId);
    }

    // ==========================================
    // calcularPromedioTatuador
    // ==========================================
    @Test
    void calcularPromedioTatuador_DeberiaCalcularElPromedioCorrectamente_CuandoHayNotas() {
        // Arrange
        List<Calificacion> calificaciones = new ArrayList<>();
        
        Calificacion c1 = new Calificacion(); c1.setPuntuacion(5);
        Calificacion c2 = new Calificacion(); c2.setPuntuacion(4);
        Calificacion c3 = new Calificacion(); c3.setPuntuacion(3);
        
        calificaciones.add(c1);
        calificaciones.add(c2);
        calificaciones.add(c3);

        // Suma = 12 / 3 elementos = Promedio esperado de 4.0
        when(repository.findByTatuadorId(tatuadorId)).thenReturn(calificaciones);

        // Act
        double promedio = calificacionService.calcularPromedioTatuador(tatuadorId);

        // Assert
        assertEquals(4.0, promedio);
        verify(repository, times(1)).findByTatuadorId(tatuadorId);
    }

    @Test
    void calcularPromedioTatuador_DeberiaRetornarCero_CuandoNoHayCalificaciones() {
        // Arrange
        // Simulamos que el tatuador no tiene ninguna reseña todavía
        when(repository.findByTatuadorId(tatuadorId)).thenReturn(Collections.emptyList());

        // Act
        double promedio = calificacionService.calcularPromedioTatuador(tatuadorId);

        // Assert
        assertEquals(0.0, promedio); // Valida la cláusula de escape .isEmpty() -> return 0.0;
        verify(repository, times(1)).findByTatuadorId(tatuadorId);
    }

    // ==========================================
    // eliminarCalificacion
    // ==========================================
    @Test
    void eliminarCalificacion_DeberiaLlamarAlDeleteById() {
        // Arrange
        Long idCalificacion = 1L;

        // Act
        calificacionService.eliminarCalificacion(idCalificacion);

        // Assert
        verify(repository, times(1)).deleteById(idCalificacion);
    }
}
