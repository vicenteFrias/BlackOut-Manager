package bm.cita.dto;

import lombok.Data;

@Data
public class FinalizarCitaDTO {
    private Long runTatuador;
    private int factorTamano;
    private double horasReales;
}