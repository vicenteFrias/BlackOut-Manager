package bm.cita.service;

import bm.cita.model.Cita;
import bm.cita.model.EstadoCita;
import bm.cita.repository.CitaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CitaService {

    @Autowired
    private CitaRepository citaRepository;

    @Autowired
    @Qualifier("carteraWebClient") 
    private WebClient carteraWebClient;

    @Autowired
    @Qualifier("agendaWebClient")
    private WebClient agendaWebClient;

    @Transactional
    public void finalizarCita(Long idCita, Long runTatuador, int factorTamano, double horasReales) {
        // 1. Buscar la cita
        Cita cita = citaRepository.findById(idCita)
                .orElseThrow(() -> new RuntimeException("Cita no encontrada con ID: " + idCita));

        // 2. Cambiar estado al Enum correcto
        cita.setEstado(EstadoCita.FINALIZADA); 
        citaRepository.save(cita);

        // 3. Preparar el Body para Cartera (JSON) 
        Map<String, Object> bodyCartera = new HashMap<>();
        bodyCartera.put("horasTotales", horasReales); 
        bodyCartera.put("factorTamano", factorTamano);
        bodyCartera.put("descripcion", "Tatuaje finalizado: " + cita.getNombreCliente());
        bodyCartera.put("idCita", idCita);

        // 4. Enviar a Cartera (8083)
        carteraWebClient.post()
                .uri("/ingresos/tatuaje/" + runTatuador)
                .bodyValue(bodyCartera)
                .retrieve()
                .bodyToMono(String.class)
                .subscribe(
                    res -> System.out.println("✅ Ingreso registrado en Cartera con " + horasReales + " horas."),
                    err -> System.err.println("❌ Error en Cartera: " + err.getMessage())
                );
    }


    @Transactional
    public Cita agendarCita(Cita nuevaCita) {
        // 1. Validación de fechas
        if (nuevaCita.getFechaHoraFin().isBefore(nuevaCita.getFechaHoraInicio())) {
            throw new RuntimeException("La fecha de fin no puede ser anterior al inicio.");
        }

        // 2. VALIDACIÓN EXTERNA (Agenda): Preguntar si el tiempo está libre en el puerto 8086
        // Usamos .block() porque es una validación crítica: si no hay respuesta o está ocupado, no seguimos.
        Boolean estaOcupadoEnAgenda = agendaWebClient.get()
            .uri(uriBuilder -> uriBuilder
                    .path("/validar-disponibilidad")
                    .queryParam("inicio", nuevaCita.getFechaHoraInicio())
                    .queryParam("fin", nuevaCita.getFechaHoraFin())
                    .build())
            .retrieve()
            .onStatus(status -> status.isError(), response -> {
                throw new RuntimeException("El servicio de Agenda no responde");
            })
            .bodyToMono(Boolean.class)
            .block();

        if (estaOcupadoEnAgenda != null && estaOcupadoEnAgenda) {
            throw new RuntimeException("No se puede agendar: El horario ya está ocupado en la agenda personal o profesional.");
        }

        // 3. Validación Local (Tatuajes previos en MS Citas)
        // Optimizamos usando el repository directamente si tienes el método, o mantenemos el stream
        boolean ocupadoLocal = citaRepository.findAll().stream().anyMatch(citaExistente -> 
            (nuevaCita.getFechaHoraInicio().isBefore(citaExistente.getFechaHoraFin()) && 
             nuevaCita.getFechaHoraFin().isAfter(citaExistente.getFechaHoraInicio())) &&
            !citaExistente.getEstado().equals(EstadoCita.CANCELADA)
        );

        if (ocupadoLocal) {
            throw new RuntimeException("Ya tienes un tatuaje agendado en ese horario.");
        }

        // 4. Preparar y Guardar localmente
        if (nuevaCita.getEstado() == null) {
            nuevaCita.setEstado(EstadoCita.PENDIENTE);
        }
        Cita guardada = citaRepository.save(nuevaCita);

        // 5. Notificar al Microservicio de Agenda para bloquear el espacio (Asíncrono)
        notificarBloqueoAgenda(guardada);

        return guardada;
    }

    private void notificarBloqueoAgenda(Cita guardada) {
        Map<String, Object> bodyAgenda = new HashMap<>();
        bodyAgenda.put("inicio", guardada.getFechaHoraInicio());
        bodyAgenda.put("fin", guardada.getFechaHoraFin());
        bodyAgenda.put("titulo", "Tatuaje: " + guardada.getNombreCliente());
        bodyAgenda.put("citaId", guardada.getId());
        bodyAgenda.put("tipo", "TATUAJE");

        agendaWebClient.post()
                .uri("/bloquear")
                .bodyValue(bodyAgenda)
                .retrieve()
                .bodyToMono(Void.class)
                .subscribe(); // No bloqueamos el hilo, que se ejecute de fondo
    }

    @Transactional
    public void eliminar(Long id) {
        citaRepository.deleteById(id);

        // Notificar a la agenda para liberar el tiempo
        agendaWebClient.delete()
                .uri("/cita/{id}", id)
                .retrieve()
                .bodyToMono(Void.class)
                .subscribe();
    }
    
    public List<Cita> obtenerHistorial(String nombre) {
        return citaRepository.buscarPorNombreCliente(nombre);
    }

    public List<Cita> obtenerAgendaDia(LocalDateTime fecha) {
        LocalDateTime inicio = fecha.withHour(0).withMinute(0).withSecond(0);
        LocalDateTime fin = fecha.withHour(23).withMinute(59).withSecond(59);
        return citaRepository.findByFechaHoraInicioBetweenOrderByFechaHoraInicioAsc(inicio, fin);
    }

    public Integer calcularSaldoPendiente(Long id) {
        Cita cita = citaRepository.findById(id).orElseThrow(() -> new RuntimeException("Cita no encontrada"));
        int total = (cita.getPrecioTotal() != null) ? cita.getPrecioTotal() : 0;
        int pagado = (cita.getAbono() != null) ? cita.getAbono() : 0;
        return total - pagado;
    }

}