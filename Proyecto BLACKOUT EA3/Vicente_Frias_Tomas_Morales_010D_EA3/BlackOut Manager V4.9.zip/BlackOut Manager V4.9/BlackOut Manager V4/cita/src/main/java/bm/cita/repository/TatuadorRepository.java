package bm.cita.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bm.cita.model.Tatuador;

@Repository
public interface TatuadorRepository extends JpaRepository<Tatuador, Long>{

}
