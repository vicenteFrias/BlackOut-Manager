package bm.cita.repository;

import bm.cita.model.Cita;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface CitaRepository extends JpaRepository<Cita, Long> {
    
    // Buscar eventos en cierto rango de tiempo
    List<Cita> findByFechaHoraInicioBetweenOrderByFechaHoraInicioAsc(LocalDateTime inicio, LocalDateTime fin);
    
    // Para buscar citas de un cliente específico 
    @Query("SELECT c FROM Cita c WHERE LOWER(c.nombreCliente) LIKE LOWER(CONCAT('%', :nombre, '%')) ORDER BY c.fechaHoraInicio DESC")
    List<Cita> buscarPorNombreCliente(@Param("nombre") String nombre);
}