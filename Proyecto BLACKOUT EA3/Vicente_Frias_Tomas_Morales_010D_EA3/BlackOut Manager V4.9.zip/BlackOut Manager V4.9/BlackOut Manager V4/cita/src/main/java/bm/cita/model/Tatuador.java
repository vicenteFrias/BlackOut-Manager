package bm.cita.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "tatuadores")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Tatuador {

    @Id
    private Long idUsuario; // Este es el ID que viene del MS Usuarios
    private String nombre;
    private String especialidad; // "Realismo", "Tradicional", etc.
}
