package bm.cita.controller;

import bm.cita.dto.FinalizarCitaDTO;
import bm.cita.model.Cita;
import bm.cita.model.Tatuador;
import bm.cita.repository.TatuadorRepository;
import bm.cita.service.CitaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1/citas")
public class CitaController {

    @Autowired
    private CitaService citaService;

    @PostMapping
    public Cita agendar(@RequestBody Cita cita) {
        return citaService.agendarCita(cita);
    }

    @GetMapping("/historial/{nombre}")
    public List<Cita> historial(@PathVariable String nombre) {
        return citaService.obtenerHistorial(nombre);
    }

    @GetMapping("/hoy")
    public List<Cita> agendaDeHoy() {
        return citaService.obtenerAgendaDia(LocalDateTime.now());
    }

    @GetMapping("/{id}/saldo")
    public Integer verSaldo(@PathVariable Long id) {
        return citaService.calcularSaldoPendiente(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable Long id) {
        citaService.eliminar(id);
        return ResponseEntity.ok("Cita eliminada correctamente");
    }

    @PostMapping("/{id}/finalizar")
    public ResponseEntity<String> finalizar(
        @PathVariable Long id,
        @RequestBody FinalizarCitaDTO dto) {
        citaService.finalizarCita(id, dto.getRunTatuador(), dto.getFactorTamano(), dto.getHorasReales());
        return ResponseEntity.ok("Cita finalizada y enviada a cartera.");
    }

    @Autowired
    private TatuadorRepository tatuadorRepository;

    @PostMapping("/tatuadores/registrar")
    public ResponseEntity<String> registrarPerfilTatuador(@RequestBody Map<String, Object> datos) {
        Long id = Long.valueOf(datos.get("idUsuario").toString());
        String nombre = (String) datos.get("nombre");

        // Creamos el perfil profesional en la DB de Citas
        Tatuador nuevoTatuador = new Tatuador();
        nuevoTatuador.setIdUsuario(id);
        nuevoTatuador.setNombre(nombre);
        nuevoTatuador.setEspecialidad("Por definir"); // Se edita después

        tatuadorRepository.save(nuevoTatuador);

        return ResponseEntity.ok("Perfil profesional creado en MS Citas");
    }
}