package bm.cita.model;

public enum EstadoCita {
    PENDIENTE,   // Creada pero sin pago de anticipo
    CONFIRMADA,  // Con anticipo pagado y espacio reservado
    CANCELADA,   // El cliente o tatuador canceló
    FINALIZADA,  // El tatuaje ya se realizó
    NOSHOW       // El cliente no llegó
}