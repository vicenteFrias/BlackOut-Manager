package bm.cita.service.test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Optional;
import java.util.function.Function;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import bm.cita.model.Cita;
import bm.cita.model.EstadoCita;
import bm.cita.repository.CitaRepository;
import bm.cita.service.CitaService;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
public class CitaServiceTest {

    @Mock
    private CitaRepository citaRepository;

    @Mock
    private WebClient carteraWebClient;

    @Mock
    private WebClient agendaWebClient;

    @InjectMocks
    private CitaService citaService;

    // Componentes para simular la interfaz fluida de WebClient
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;
    private WebClient.RequestBodySpec requestBodySpec;
    private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;
    private WebClient.RequestHeadersSpec requestHeadersSpec;
    private WebClient.ResponseSpec responseSpec;

    @BeforeEach
    @SuppressWarnings("unchecked")
    void setUp() {
        requestBodyUriSpec = mock(WebClient.RequestBodyUriSpec.class);
        requestBodySpec = mock(WebClient.RequestBodySpec.class);
        requestHeadersUriSpec = mock(WebClient.RequestHeadersUriSpec.class);
        requestHeadersSpec = mock(WebClient.RequestHeadersSpec.class);
        responseSpec = mock(WebClient.ResponseSpec.class);

        // Comportamientos por defecto (lenient) para evitar fallos por encadenamiento intermedio
        lenient().when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        lenient().when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
        lenient().when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        
        // Interceptores clave para capturar las llamadas dinámicas con funciones lambda del servicio
        lenient().when(requestHeadersUriSpec.uri(any(Function.class))).thenReturn(requestHeadersSpec);
        lenient().when(requestHeadersUriSpec.uri(anyString(), anyLong())).thenReturn(requestHeadersSpec);
    }

    // =========================================================================
    // 1. TESTS: finalizarCita
    // =========================================================================
    @Test
    @DisplayName("Debería finalizar una cita cambiando su estado a FINALIZADA e invocando la API Cartera")
    void finalizarCita_Exitoso() {
        // Given
        Long idCita = 1L;
        Long runTatuador = 12345678L;

        Cita cita = new Cita();
        cita.setId(idCita);
        cita.setNombreCliente("Diego Silva");
        cita.setEstado(EstadoCita.PENDIENTE);

        when(citaRepository.findById(idCita)).thenReturn(Optional.of(cita));
        when(citaRepository.save(any(Cita.class))).thenAnswer(i -> i.getArgument(0));

        // Mock del flujo POST de Cartera
        when(carteraWebClient.post()).thenReturn(requestBodyUriSpec);
        when(responseSpec.bodyToMono(String.class)).thenReturn(Mono.just("Éxito"));

        // When
        assertDoesNotThrow(() -> citaService.finalizarCita(idCita, runTatuador, 2, 3.5));

        // Then
        assertEquals(EstadoCita.FINALIZADA, cita.getEstado());
        verify(citaRepository, times(1)).save(cita);
        verify(carteraWebClient, times(1)).post();
    }

    @Test
    @DisplayName("Debería lanzar excepción si la cita no existe al intentar finalizar")
    void finalizarCita_NoEncontrada() {
        // Given
        Long idCita = 99L;
        when(citaRepository.findById(idCita)).thenReturn(Optional.empty());

        // When & Then
        assertThrows(RuntimeException.class, () -> 
            citaService.finalizarCita(idCita, 123456L, 1, 2.0)
        );
        verify(citaRepository, never()).save(any(Cita.class));
    }

    // =========================================================================
    // 2. TESTS: agendarCita (CON LA CORRECCIÓN DE DEFAULTIFEMPTY)
    // =========================================================================
    @Test
    @DisplayName("Debería agendar una cita correctamente si la agenda externa retorna Mono con false")
    void agendarCita_Exitoso() {
        // Given
        Cita nuevaCita = new Cita();
        nuevaCita.setFechaHoraInicio(LocalDateTime.now().plusDays(1));
        nuevaCita.setFechaHoraFin(LocalDateTime.now().plusDays(1).plusHours(2));
        nuevaCita.setEstado(null);

        // 1. Simular validación externa GET (Mapeando tu flujo reactivo corregido)
        when(agendaWebClient.get()).thenReturn(requestHeadersUriSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        
        // Entrenamos al Mono real para emitir false. defaultIfEmpty pasará de largo porque no viene vacío.
        when(responseSpec.bodyToMono(Boolean.class)).thenReturn(Mono.just(false)); 

        // 2. Simular validación local (No hay colisiones en la BD)
        when(citaRepository.findAll()).thenReturn(new ArrayList<>());
        when(citaRepository.save(any(Cita.class))).thenAnswer(i -> i.getArgument(0));

        // 3. Simular notificación POST asíncrona hacia la agenda
        when(agendaWebClient.post()).thenReturn(requestBodyUriSpec);
        when(responseSpec.bodyToMono(Void.class)).thenReturn(Mono.empty());

        // When
        Cita resultado = citaService.agendarCita(nuevaCita);

        // Then
        assertNotNull(resultado);
        assertEquals(EstadoCita.PENDIENTE, resultado.getEstado());
        verify(citaRepository, times(1)).save(nuevaCita);
    }

    @Test
    @DisplayName("Debería lanzar excepción si la agenda externa responde que el horario está ocupado (true)")
    void agendarCita_ErrorAgendaOcupada() {
        // Given
        Cita nuevaCita = new Cita();
        nuevaCita.setFechaHoraInicio(LocalDateTime.now().plusDays(1));
        nuevaCita.setFechaHoraFin(LocalDateTime.now().plusDays(1).plusHours(2));

        when(agendaWebClient.get()).thenReturn(requestHeadersUriSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        
        // Simula que la API externa devolvió TRUE (Horario bloqueado en servidor externo)
        when(responseSpec.bodyToMono(Boolean.class)).thenReturn(Mono.just(true)); 

        // When & Then
        RuntimeException ex = assertThrows(RuntimeException.class, () -> citaService.agendarCita(nuevaCita));
        assertTrue(ex.getMessage().contains("El horario ya está ocupado en la agenda"));
        
        verify(citaRepository, never()).save(any(Cita.class));
    }

    @Test
    @DisplayName("Debería lanzar excepción si las fechas de inicio/fin están invertidas de forma errónea")
    void agendarCita_ErrorFechasInvertidas() {
        // Given
        Cita nuevaCita = new Cita();
        nuevaCita.setFechaHoraInicio(LocalDateTime.now().plusHours(3));
        nuevaCita.setFechaHoraFin(LocalDateTime.now().plusHours(1)); // Fin antes que inicio

        // When & Then
        RuntimeException ex = assertThrows(RuntimeException.class, () -> citaService.agendarCita(nuevaCita));
        assertTrue(ex.getMessage().contains("La fecha de fin no puede ser anterior al inicio"));
    }

    // =========================================================================
    // 3. TEST: eliminar
    // =========================================================================
    @Test
    @DisplayName("Debería eliminar físicamente y notificar vía DELETE al microservicio de Agenda")
    void eliminarCita_Exitoso() {
        // Given
        Long idCita = 5L;
        doNothing().when(citaRepository).deleteById(idCita);

        // Mock del flujo DELETE hacia la Agenda
        when(agendaWebClient.delete()).thenReturn(requestHeadersUriSpec);
        when(responseSpec.bodyToMono(Void.class)).thenReturn(Mono.empty());

        // When
        assertDoesNotThrow(() -> citaService.eliminar(idCita));

        // Then
        verify(citaRepository, times(1)).deleteById(idCita);
        verify(agendaWebClient, times(1)).delete();
    }

    // =========================================================================
    // 4. TESTS: calcularSaldoPendiente
    // =========================================================================
    @Test
    @DisplayName("Debería calcular el saldo restando los abonos correctamente")
    void calcularSaldoPendiente_CalculoCorrecto() {
        // Given
        Long idCita = 10L;
        Cita cita = new Cita();
        cita.setPrecioTotal(150000); 
        cita.setAbono(40000);        

        when(citaRepository.findById(idCita)).thenReturn(Optional.of(cita));

        // When
        Integer saldo = citaService.calcularSaldoPendiente(idCita);

        // Then
        assertEquals(110000, saldo);
    }

    @Test
    @DisplayName("Debería retornar cero si las propiedades financieras evalúan a nulo")
    void calcularSaldoPendiente_ValoresNulos() {
        // Given
        Long idCita = 10L;
        Cita cita = new Cita();
        cita.setPrecioTotal(null);
        cita.setAbono(null);

        when(citaRepository.findById(idCita)).thenReturn(Optional.of(cita));

        // When
        Integer saldo = citaService.calcularSaldoPendiente(idCita);

        // Then
        assertEquals(0, saldo);
    }
}