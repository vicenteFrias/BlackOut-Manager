package bm.productos.service.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import bm.productos.dto.InsumoRequestDTO;
import bm.productos.model.Insumo;
import bm.productos.model.MovimientoStock;
import bm.productos.model.TipoMovimiento;
import bm.productos.repository.InsumoRepository;
import bm.productos.repository.MovimientoStockRepository;
import bm.productos.service.StockService;

@ExtendWith(MockitoExtension.class)
public class stockServiceTest {

    @Mock // Ocupamos mock para que desde el original duplique el atributo
    private InsumoRepository insumoRepository; //Simulamos elrepositorio

    @Mock
    private MovimientoStockRepository movimientoStockRepository;

    @InjectMocks // 
    private StockService stockService; // Intectamos el mkock en el servicio real

    // ==========================================
    // 1. TEST: registrarNuevoInsumo
    // ==========================================
    @Test
    @DisplayName("Debería registrar un nuevo insumo correctamente")
    void registrarNuevoInsumoTest() {
        InsumoRequestDTO dto = new InsumoRequestDTO();
        dto.setNombre("Tinta");
        dto.setMarca("Eternal ink");
        dto.setStockInicial(80);
        dto.setStockMinimo(10);
        dto.setCostoUnitarioBase(10000);

        when(insumoRepository.save(any(Insumo.class))).thenAnswer(invocation -> {
            Insumo p = invocation.getArgument(0);
            p.setId(1L); 
            return p;
        });

        Insumo resultado = stockService.registrarNuevoInsumo(dto);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());
        assertEquals("Tinta", resultado.getNombre());
        assertEquals(80, resultado.getCantidadActual()); // Mapeado de stockInicial

        verify(insumoRepository, times(1)).save(any(Insumo.class));
    }

    // ==========================================
    // 2. TESTS: actualizarStockManual
    // ==========================================
    @Test
    @DisplayName("Debería actualizar stock manual exitosamente y registrar el movimiento")
    void actualizarStockManual_Exitoso() {
        Long insumoId = 1L;
        Integer cantidadCambio = 5; // Entrada de stock
        
        Insumo insumoExistente = new Insumo();
        insumoExistente.setId(insumoId);
        insumoExistente.setNombre("Agujas");
        insumoExistente.setCantidadActual(10);
        insumoExistente.setStockMinimo(5);

        when(insumoRepository.findById(insumoId)).thenReturn(Optional.of(insumoExistente));
        when(insumoRepository.save(any(Insumo.class))).thenReturn(insumoExistente);
        when(movimientoStockRepository.save(any(MovimientoStock.class))).thenAnswer(i -> i.getArgument(0));

        MovimientoStock resultado = stockService.actualizarStockManual(insumoId, cantidadCambio, TipoMovimiento.COMPRA);

        assertNotNull(resultado);
        assertEquals(insumoId, resultado.getInsumoId());
        assertEquals(5, resultado.getCantidad());
        assertEquals(TipoMovimiento.COMPRA, resultado.getTipo());
        assertEquals(15, insumoExistente.getCantidadActual()); // 10 iniciales + 5 nuevos

        verify(insumoRepository, times(1)).findById(insumoId);
        verify(insumoRepository, times(1)).save(insumoExistente);
        verify(movimientoStockRepository, times(1)).save(any(MovimientoStock.class));
    }

    @Test
    @DisplayName("Debería lanzar excepción si el stock resultante es negativo")
    void actualizarStockManual_ErrorStockInsuficiente() {
        Long insumoId = 1L;
        Integer cantidadCambio = -15; // Intentamos sacar más de lo que hay
        
        Insumo insumoExistente = new Insumo();
        insumoExistente.setId(insumoId);
        insumoExistente.setCantidadActual(10);

        when(insumoRepository.findById(insumoId)).thenReturn(Optional.of(insumoExistente));

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            stockService.actualizarStockManual(insumoId, cantidadCambio, TipoMovimiento.USO_SESION);
        });

        assertTrue(exception.getMessage().contains("Stock insuficiente"));
        verify(insumoRepository, never()).save(any(Insumo.class)); // No debería guardar nada
        verify(movimientoStockRepository, never()).save(any(MovimientoStock.class));
    }

    // ==========================================
    // 3. TESTS: editarDatosBasicos
    // ==========================================
    @Test
    @DisplayName("Debería editar datos básicos cuando los campos no son nulos ni vacíos")
    void editarDatosBasicos_Exitoso() {
        Long id = 1L;
        Insumo insumoExistente = new Insumo();
        insumoExistente.setId(id);
        insumoExistente.setNombre("Nombre Viejo");
        insumoExistente.setStockMinimo(5);

        when(insumoRepository.findById(id)).thenReturn(Optional.of(insumoExistente));
        when(insumoRepository.save(any(Insumo.class))).thenReturn(insumoExistente);

        Insumo resultado = stockService.editarDatosBasicos(id, "Nombre Nuevo", 15);

        assertNotNull(resultado);
        assertEquals("Nombre Nuevo", resultado.getNombre());
        assertEquals(15, resultado.getStockMinimo());

        verify(insumoRepository, times(1)).save(insumoExistente);
    }

    // ==========================================
    // 4. TEST: listarMovimientosPorRango
    // ==========================================
    @Test
    @DisplayName("Debería listar movimientos expandiendo las fechas a inicio y fin de día")
    void listarMovimientosPorRangoTest() {
        LocalDate fecha = LocalDate.of(2026, 6, 16);
        
        // El servicio usa atStartOfDay() y atTime(LocalTime.MAX) internamente
        LocalDateTime inicioEsperado = fecha.atStartOfDay();
        LocalDateTime finEsperado = fecha.atTime(java.time.LocalTime.MAX);

        MovimientoStock m = new MovimientoStock();
        when(movimientoStockRepository.findByFechaBetween(inicioEsperado, finEsperado)).thenReturn(List.of(m));

        List<MovimientoStock> resultado = stockService.listarMovimientosPorRango(fecha, fecha);

        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        verify(movimientoStockRepository, times(1)).findByFechaBetween(inicioEsperado, finEsperado);
    }

    // ==========================================
    // 5. TEST: obtenerInventarioCompleto
    // ==========================================
    @Test
    @DisplayName("Debería obtener la lista completa de insumos")
    void obtenerInventarioCompletoTest() {
        Insumo i1 = new Insumo();
        Insumo i2 = new Insumo();
        when(insumoRepository.findAll()).thenReturn(List.of(i1, i2));

        List<Insumo> resultado = stockService.obtenerInventarioCompleto();

        assertNotNull(resultado);
        assertEquals(2, resultado.size());
        verify(insumoRepository, times(1)).findAll();
    }
}
