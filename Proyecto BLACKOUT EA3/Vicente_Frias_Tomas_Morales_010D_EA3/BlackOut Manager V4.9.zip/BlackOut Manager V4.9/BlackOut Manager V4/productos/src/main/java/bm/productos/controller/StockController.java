package bm.productos.controller;

import bm.productos.model.Insumo;
import bm.productos.model.MovimientoStock;
import bm.productos.model.TipoMovimiento;
import bm.productos.repository.InsumoRepository;
import bm.productos.service.StockService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1/productos")
public class StockController {

    @Autowired
    private StockService stockService;

    @Autowired
    private InsumoRepository insumoRepository;

    /**
    CREACIÓN DE INSUMO
    */
    @PostMapping("/insumos")
    public ResponseEntity<Insumo> crearInsumo(
            @RequestParam String nombre,
            @RequestParam Integer stockInicial,
            @RequestParam Integer stockMinimo) {
        
        Insumo nuevo = new Insumo();
        nuevo.setNombre(nombre);
        nuevo.setCantidadActual(stockInicial);
        nuevo.setStockMinimo(stockMinimo);
        
        return ResponseEntity.ok(insumoRepository.save(nuevo));
    }

    /**
    ACTUALIZACIÓN DE STOCK (Físico)
    */
    @PostMapping("/stock/actualizar")
    public ResponseEntity<MovimientoStock> actualizarStock(
            @RequestParam Long insumoId,
            @RequestParam Integer cantidad,
            @RequestParam TipoMovimiento tipo) {
        
        MovimientoStock movimiento = stockService.actualizarStockManual(insumoId, cantidad, tipo);
        return ResponseEntity.ok(movimiento);
    }

    @PutMapping("/insumos/{id}")
    public ResponseEntity<Insumo> editarInsumo(
    @PathVariable Long id,
    @RequestParam(required = false) String nombre,
    @RequestParam(required = false) Integer stockMinimo) {
    
        Insumo actualizado = stockService.editarDatosBasicos(id, nombre, stockMinimo);
        return ResponseEntity.ok(actualizado);
    }

    /**
    CONSULTA DE INVENTARIO
     */
    @GetMapping("/inventario")
    public ResponseEntity<List<Insumo>> obtenerInventario() {
        return ResponseEntity.ok(stockService.obtenerInventarioCompleto());
    }

    /**
    HISTORIAL DE MOVIMIENTOS
    */
    @GetMapping("/movimientos/historial")
    public ResponseEntity<List<MovimientoStock>> obtenerHistorial(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate inicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fin) {
        
        return ResponseEntity.ok(stockService.listarMovimientosPorRango(inicio, fin));
    }
}