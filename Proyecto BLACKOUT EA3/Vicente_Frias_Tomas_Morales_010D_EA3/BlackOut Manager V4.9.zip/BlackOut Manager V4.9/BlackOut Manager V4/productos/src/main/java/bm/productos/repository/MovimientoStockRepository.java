package bm.productos.repository;

import bm.productos.model.MovimientoStock;
import bm.productos.model.TipoMovimiento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface MovimientoStockRepository extends JpaRepository<MovimientoStock, Long> {

    // Regla de Oro: Búsqueda por rango de fechas (ya expandidas en el Service)
    List<MovimientoStock> findByFechaBetween(LocalDateTime inicio, LocalDateTime fin);

    // Para filtrar por tipo (ej: ver solo COMPRAS de un mes)
    List<MovimientoStock> findByTipoAndFechaBetween(TipoMovimiento tipo, LocalDateTime inicio, LocalDateTime fin);
}