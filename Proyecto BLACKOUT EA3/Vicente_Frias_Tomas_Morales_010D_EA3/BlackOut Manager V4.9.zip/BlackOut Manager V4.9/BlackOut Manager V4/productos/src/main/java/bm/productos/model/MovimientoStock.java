package bm.productos.model;

import java.time.LocalDateTime;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@EntityListeners(AuditingEntityListener.class)
public class MovimientoStock {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(accessMode = Schema.AccessMode.READ_ONLY, description = "ID autoincremental generado por la BD")
    private Long id;
    
    private Long insumoId; // Relación lógica
    private Integer cantidad; // Positivo para entrada, negativo para salida
    
    @Enumerated(EnumType.STRING)
    private TipoMovimiento tipo; // COMPRA, USO_SESION, PERDIDA, AJUSTE
    
    // Aquí aplicamos tu regla de oro financiera
    private Integer costoCalculadoPF; 
    
    @CreatedDate
    private LocalDateTime fecha;
}