package bm.productos.dto;

import lombok.Data;

@Data
public class InsumoRequestDTO {
    private String nombre;
    private String marca;
    private Integer stockInicial;
    private Integer stockMinimo;
    private Integer costoUnitarioBase;
}