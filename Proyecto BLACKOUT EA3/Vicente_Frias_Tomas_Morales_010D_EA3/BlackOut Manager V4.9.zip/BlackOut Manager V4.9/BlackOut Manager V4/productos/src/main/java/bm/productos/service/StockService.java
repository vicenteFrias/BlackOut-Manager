package bm.productos.service;

import bm.productos.dto.InsumoRequestDTO;
import bm.productos.model.Insumo;
import bm.productos.model.MovimientoStock;
import bm.productos.model.TipoMovimiento;
import bm.productos.repository.InsumoRepository;
import bm.productos.repository.MovimientoStockRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

@Service
public class StockService {

    @Autowired
    private InsumoRepository insumoRepository;

    @Autowired
    private MovimientoStockRepository movimientoRepository;

    @Transactional
    public Insumo registrarNuevoInsumo(InsumoRequestDTO dto) {
        Insumo nuevo = new Insumo();
        nuevo.setNombre(dto.getNombre());
        nuevo.setMarca(dto.getMarca());
        nuevo.setCantidadActual(dto.getStockInicial());
        nuevo.setStockMinimo(dto.getStockMinimo());
        nuevo.setCostoUnitarioBase(dto.getCostoUnitarioBase());
    
        return insumoRepository.save(nuevo);
    }

    @Transactional
    public MovimientoStock actualizarStockManual(Long insumoId, Integer cantidad, TipoMovimiento tipo) {
        Insumo insumo = insumoRepository.findById(insumoId)
                .orElseThrow(() -> new RuntimeException("Insumo no encontrado"));

        int nuevaCantidad = insumo.getCantidadActual() + cantidad;

        // Validación: No permitir stock negativo
        if (nuevaCantidad < 0) {
            throw new RuntimeException("Error: Stock insuficiente. Solo quedan " + insumo.getCantidadActual() + " unidades.");
        }

        // Alerta: Si el stock queda igual o por debajo del mínimo definido
        if (nuevaCantidad <= insumo.getStockMinimo()) {
            System.out.println("⚠️ ALERTA: Stock crítico para " + insumo.getNombre() + ". Quedan: " + nuevaCantidad);
        }

        insumo.setCantidadActual(nuevaCantidad);
        insumoRepository.save(insumo);

        MovimientoStock movimiento = new MovimientoStock();
        movimiento.setInsumoId(insumoId);
        movimiento.setCantidad(cantidad);
        movimiento.setTipo(tipo);

        return movimientoRepository.save(movimiento);
    }

    @Transactional
    public Insumo editarDatosBasicos(Long id, String nuevoNombre, Integer nuevoStockMinimo) {
        Insumo insumo = insumoRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Insumo no encontrado"));

        if (nuevoNombre != null && !nuevoNombre.isEmpty()) {
            insumo.setNombre(nuevoNombre);
        }
    
        if (nuevoStockMinimo != null) {
            insumo.setStockMinimo(nuevoStockMinimo);
        }

        return insumoRepository.save(insumo);
    }

    // Regla de Oro: Expansión de fechas para reportes de inventario
    public List<MovimientoStock> listarMovimientosPorRango(LocalDate fechaInicio, LocalDate fechaFin) {
        LocalDateTime inicio = fechaInicio.atStartOfDay();
        LocalDateTime fin = fechaFin.atTime(LocalTime.MAX);
        return movimientoRepository.findByFechaBetween(inicio, fin);
    }

    public List<Insumo> obtenerInventarioCompleto() {
        return insumoRepository.findAll();
    }
}