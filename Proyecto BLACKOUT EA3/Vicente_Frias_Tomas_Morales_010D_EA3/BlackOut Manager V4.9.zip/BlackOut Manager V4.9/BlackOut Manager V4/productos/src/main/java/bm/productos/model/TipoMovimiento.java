package bm.productos.model;

public enum TipoMovimiento {
    COMPRA,
    USO_SESION,
    PERDIDA,
    AJUSTE
}