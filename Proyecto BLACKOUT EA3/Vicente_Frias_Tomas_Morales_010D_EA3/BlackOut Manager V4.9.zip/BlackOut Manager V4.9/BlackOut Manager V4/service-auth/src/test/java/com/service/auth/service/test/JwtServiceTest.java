package com.service.auth.service.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.service.auth.service.JwtService;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@ExtendWith(MockitoExtension.class)
class JwtServiceTest {

    @InjectMocks
    private JwtService jwtService;

    // Un secreto largo simulado (HS256 requiere una clave de al menos 256 bits / 32 caracteres)
    private final String secretoSimulado = "mi_clave_secreta_super_segura_y_larga_para_el_tatuador_studio_2026";

    @BeforeEach
    void setUp() {
        // Inyectamos manualmente el valor en el atributo privado "secreto" que usa el @Value
        ReflectionTestUtils.setField(jwtService, "secreto", secretoSimulado);
    }

    @Test
    void generarToken_DeberiaCrearUnTokenValidoConClaimsCorrectos() {
        // Arrange
        String username = "tatuador_pro";
        List<String> roles = Arrays.asList("ROLE_TATUADOR", "ROLE_ADMIN");

        // Act
        String token = jwtService.generarToken(username, roles);

        // Assert
        assertNotNull(token);
        assertFalse(token.trim().isEmpty());

        // Para verificar que quedó bien hecho, lo parseamos usando la misma clave secreta
        Claims claims = Jwts.parserBuilder()
                .setSigningKey(Keys.hmacShaKeyFor(secretoSimulado.getBytes()))
                .build()
                .parseClaimsJws(token)
                .getBody();

        // 1. Validar el Subject (username)
        assertEquals(username, claims.getSubject());

        // 2. Validar los Claims personalizados (roles)
        List<?> rolesEnToken = claims.get("roles", List.class);
        assertNotNull(rolesEnToken);
        assertEquals(2, rolesEnToken.size());
        assertTrue(rolesEnToken.contains("ROLE_TATUADOR"));

        // 3. Validar los tiempos (Expiración)
        Date expiration = claims.getExpiration();
        Date issuedAt = claims.getIssuedAt();
        assertNotNull(expiration);
        assertNotNull(issuedAt);

        // Comprobamos la diferencia de tiempo (debería ser de aproximadamente 2 horas en milisegundos)
        long diferenciaMilisegundos = expiration.getTime() - issuedAt.getTime();
        long dosHorasEsperadas = 1000L * 60 * 60 * 2;
        
        // Tolerancia de 1000ms por retrasos mínimos en la ejecución del test
        assertTrue(Math.abs(diferenciaMilisegundos - dosHorasEsperadas) < 1000);
    }
}
