package com.service.auth.service.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.service.auth.model.Rol;
import com.service.auth.model.Usuario;
import com.service.auth.repository.UsuarioRepository;
import com.service.auth.service.AuthService;
import com.service.auth.service.JwtService;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private UsuarioRepository usuarioRepo;

    @Mock
    private JwtService jwtService;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private AuthService authService;

    private Usuario usuarioMock;
    private String username;
    private String passwordPlana;
    private String passwordEncriptada;

    @BeforeEach
    void setUp() {
        username = "tatuador_juan";
        passwordPlana = "123456";
        passwordEncriptada = "$2a$10$encodedPasswordExample";

        // Inicializamos la entidad Usuario con roles simulados
        usuarioMock = new Usuario();
        usuarioMock.setNombreUsuario(username);
        usuarioMock.setContrasena(passwordEncriptada);

        // Simulamos la estructura interna de roles de tu modelo
        Set<Rol> roles = new java.util.HashSet<>();
        Rol rolTatuador = new Rol();
        rolTatuador.setNombreRol("ROLE_TATUADOR");
        roles.add(rolTatuador);
        
        usuarioMock.setRoles(roles);
    }

    // ==========================================
    // TESTS PARA registrar
    // ==========================================
    @Test
    void registrar_DeberiaEncriptarContrasenaYGuardarUsuario() {
        // Arrange
        Usuario nuevoUsuario = new Usuario();
        nuevoUsuario.setNombreUsuario("nuevo_user");
        nuevoUsuario.setContrasena(passwordPlana);

        when(passwordEncoder.encode(passwordPlana)).thenReturn(passwordEncriptada);
        when(usuarioRepo.save(any(Usuario.class))).thenReturn(nuevoUsuario);

        // Act
        String resultado = authService.registrar(nuevoUsuario);

        // Assert
        assertEquals("Usuario registrado", resultado);
        assertEquals(passwordEncriptada, nuevoUsuario.getContrasena()); // Verifica que se seteó la clave encriptada
        
        verify(passwordEncoder, times(1)).encode(passwordPlana);
        verify(usuarioRepo, times(1)).save(nuevoUsuario);
    }

    // ==========================================
    // TESTS PARA login
    // ==========================================
    @Test
    void login_DeberiaRetornarToken_CuandoCredencialesSonCorrectas() {
        // Arrange
        String tokenEsperado = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0YXR1YWRvcl9qdWFuIn0...";
        List<String> rolesEsperados = List.of("ROLE_TATUADOR");

        when(usuarioRepo.findByNombreUsuario(username)).thenReturn(Optional.of(usuarioMock));
        when(passwordEncoder.matches(passwordPlana, passwordEncriptada)).thenReturn(true);
        when(jwtService.generarToken(username, List.of("ROLE_TATUADOR"))).thenReturn(tokenEsperado);

        // Act
        String tokenResultado = authService.login(username, passwordPlana);

        // Assert
        assertNotNull(tokenResultado);
        assertEquals(tokenEsperado, tokenResultado);

        verify(usuarioRepo, times(1)).findByNombreUsuario(username);
        verify(passwordEncoder, times(1)).matches(passwordPlana, passwordEncriptada);
        verify(jwtService, times(1)).generarToken(username, rolesEsperados);
    }

    @Test
    void login_DeberiaLanzarException_CuandoUsuarioNoExiste() {
        // Arrange
        when(usuarioRepo.findByNombreUsuario(username)).thenReturn(Optional.empty());

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            authService.login(username, passwordPlana);
        });

        assertEquals("Usuario no encontrado", exception.getMessage());
        
        // El flujo se corta inmediatamente, no debe validar clave ni generar token
        verify(passwordEncoder, never()).matches(any(), any());
        verify(jwtService, never()).generarToken(any(), any());
    }

    @Test
    void login_DeberiaLanzarException_CuandoContrasenaNoCoincide() {
        // Arrange
        String passwordIncorrecta = "clave_erronea";
        when(usuarioRepo.findByNombreUsuario(username)).thenReturn(Optional.of(usuarioMock));
        // matches devuelve false si no coincide la clave plana con el hash de la BD
        when(passwordEncoder.matches(passwordIncorrecta, passwordEncriptada)).thenReturn(false);

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            authService.login(username, passwordIncorrecta);
        });

        assertEquals("Credenciales invalidas", exception.getMessage());
        
        // Verifica que se buscó y se comparó, pero NUNCA se llegó a procesar el JWT
        verify(passwordEncoder, times(1)).matches(passwordIncorrecta, passwordEncriptada);
        verify(jwtService, never()).generarToken(any(), any());
    }
}
