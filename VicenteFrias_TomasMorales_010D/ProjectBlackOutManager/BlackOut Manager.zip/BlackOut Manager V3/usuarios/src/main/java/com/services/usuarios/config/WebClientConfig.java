package com.services.usuarios.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Bean
    public WebClient citasWebClient() {
        return WebClient.builder()
                .baseUrl("http://localhost:8085/api/citas") 
                .build();
    }

}
