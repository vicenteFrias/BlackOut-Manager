package bm.cita.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "citas")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Cita {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // --- TIEMPOS DE LA AGENDA ---
    @Column(nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime fechaHoraInicio;
    
    @Column(nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime fechaHoraFin;

    // --- DATOS DEL CLIENTE (Rápido, sin IDs externos) ---
    private String nombreCliente; // Solo para saber a quién tatúas
    private String contactoCliente; // WhatsApp o Instagram para avisarle

    // --- DETALLES DEL TRABAJO ---
    @Column(length = 1000)
    private String descripcionDiseno;
    
    @Enumerated(EnumType.STRING)
    private EstadoCita estado; // PENDIENTE, CONFIRMADA, FINALIZADA, CANCELADA

    @Column(precision = 10, scale = 2)
    private Integer precioTotal;
    
    @Column(precision = 10, scale = 2)
    private Integer abono; // Dinero que ya te entregaron para asegurar

    @CreationTimestamp
    @Column(updatable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime fechaRegistro;
}