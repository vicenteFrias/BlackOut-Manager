package bm.agenda.controller;

import bm.agenda.dto.SlotAgendaDTO;
import bm.agenda.model.SlotAgenda;
import bm.agenda.service.AgendaService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/agenda")
public class AgendaController {

    private static final Logger log = LoggerFactory.getLogger(AgendaController.class);

    @Autowired
    private AgendaService agendaService;

    /**
     * Valida disponibilidad total. 
     * Cumple con IE 2.4.2 al exponer un endpoint claro para otros MS.
     */
    @GetMapping("/validar-disponibilidad")
    public ResponseEntity<Boolean> validar(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime inicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fin) {
        log.info("Consulta de disponibilidad recibida: {} - {}", inicio, fin);
        boolean disponible = agendaService.verificarDisponibilidadTotal(inicio, fin);
        return ResponseEntity.ok(disponible);
    }

    /**
     * Bloquea tiempo para una cita.
     * Usa @Valid para cumplir con IE 2.2.2 (Bean Validation).
     */
    @PostMapping("/bloquear")
    public ResponseEntity<SlotAgenda> bloquear(@Valid @RequestBody SlotAgendaDTO dto) {
        log.info("Petición para bloquear slot: {}", dto.getTitulo());
        
        // Mapeo manual de DTO a Entity (necesario para el Service)
        SlotAgenda slot = new SlotAgenda();
        slot.setInicio(dto.getInicio());
        slot.setFin(dto.getFin());
        slot.setTitulo(dto.getTitulo());
        slot.setTipo(dto.getTipo());
        slot.setCitaId(dto.getCitaId());

        SlotAgenda guardado = agendaService.guardarOActualizar(slot);
        return ResponseEntity.status(HttpStatus.CREATED).body(guardado);
    }

    /**
     * Crea una actividad personal (Gimnasio, almuerzo, etc).
     */
    @PostMapping("/personal")
    public ResponseEntity<SlotAgenda> crearPersonal(@Valid @RequestBody SlotAgendaDTO dto) {
        log.info("Creando actividad personal: {}", dto.getTitulo());
        
        SlotAgenda personal = new SlotAgenda();
        personal.setInicio(dto.getInicio());
        personal.setFin(dto.getFin());
        personal.setTitulo(dto.getTitulo());

        SlotAgenda guardado = agendaService.guardarActividadPersonal(personal);
        return ResponseEntity.status(HttpStatus.CREATED).body(guardado);
    }

    /**
     * Visualización de la agenda con ResponseEntity.
     */
    @GetMapping("/ver")
    public ResponseEntity<List<SlotAgenda>> verAgenda(
            @RequestParam(required = false) 
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fecha) {
        
        LocalDateTime consulta = (fecha != null) ? fecha : LocalDateTime.now();
        List<SlotAgenda> lista = agendaService.obtenerAgendaDelDia(consulta);
        
        return lista.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(lista);
    }

    @GetMapping("/buscar")
    public ResponseEntity<List<SlotAgenda>> buscar(@RequestParam String titulo) {
        return ResponseEntity.ok(agendaService.buscarPorTitulo(titulo));
    }

    /**
     * Elimina bloqueo por cancelación en el MS de Citas.
     */
    @DeleteMapping("/cita/{citaId}")
    public ResponseEntity<Void> borrarPorCita(@PathVariable Long citaId) {
        log.warn("Eliminando slots asociados a la cita ID: {}", citaId);
        agendaService.eliminarPorCita(citaId);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> borrarManual(@PathVariable Long id) {
        agendaService.eliminarManual(id);
        return ResponseEntity.noContent().build();
    }
}