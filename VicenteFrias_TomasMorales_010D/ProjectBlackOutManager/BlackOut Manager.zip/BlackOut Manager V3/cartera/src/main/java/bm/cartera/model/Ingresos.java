package bm.cartera.model;

import java.time.LocalDateTime;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "ingresos")
@Data
@AllArgsConstructor
@NoArgsConstructor
@EntityListeners(AuditingEntityListener.class)
public class Ingresos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idIngreso;

    @NotNull(message = "El monto es obligatorio")
    @Min(value = 0, message = "La cantidad no puede ser menor a cero")
    @Column(precision = 10, scale = 2)
    private Integer monto; 

    @CreatedDate
    @Column(nullable = false, updatable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime fecha;

    @NotBlank(message = "La descripción es necesaria para el historial")
    private String descripcion;

    // Relación con el microservicio de citas (ID de referencia)
    private Long idCita;

    @NotBlank(message = "Debes especificar el método de pago")
    private String metodoPago; 
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_cartera", nullable = false)
    private Cartera cartera;
}