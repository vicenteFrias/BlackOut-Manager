package bm.cartera.controller;

import bm.cartera.dto.GastoRequestDTO;
import bm.cartera.dto.IngresoRequestDTO;
import bm.cartera.model.Gastos;
import bm.cartera.model.Ingresos;
import jakarta.validation.Valid;
import bm.cartera.Service.FinanzasService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/finanzas")
public class FinanzasController {

    @Autowired
    private FinanzasService finanzasService;

    // REGISTRAR INGRESO: Ahora usa el DTO para recibir todo en un solo JSON
    @PostMapping("/ingresos/tatuaje/{run}")
    public ResponseEntity<Ingresos> registrarTatuaje(
            @PathVariable Long run,
            @RequestBody IngresoRequestDTO request) {
        
        return ResponseEntity.ok(finanzasService.registrarTatuaje(
                run, 
                request.getHorasTotales(), 
                request.getFactorTamano(), 
                request.getDescripcion(), 
                request.getIdCita()));
    }

    // REGISTRAR GASTO: Usamos RequestParam para no complicar el Body
    @PostMapping("/gastos/{run}")
    public ResponseEntity<Gastos> registrarGasto(
            @PathVariable Long run,
            @Valid @RequestBody GastoRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(finanzasService.registrarGasto(run, dto));
    }

    // REPORTES: Usamos RequestParam (más estándar para GET)
    @GetMapping("/reportes/ingresos-rango/{run}")
    public ResponseEntity<Integer> getIngresosEnRango(
            @PathVariable Long run,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate inicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fin) {
        
        LocalDateTime fechaInicio = inicio.atStartOfDay();
        LocalDateTime fechaFin = fin.atTime(23, 59, 59);
        
        return ResponseEntity.ok(finanzasService.calcularIngresosEnRango(run, fechaInicio, fechaFin));
    }
}