package bm.cartera.model;

import java.time.LocalDateTime;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "cartera")
@Data
@AllArgsConstructor
@NoArgsConstructor
@EntityListeners(AuditingEntityListener.class) // Habilita la auditoría automática
public class Cartera {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Autoincremental para mayor facilidad
    private Long idCartera;

    @Column(nullable = false, unique = true)
    private Long runTatuador;

    @Min(value = 0, message = "El saldo no puede ser negativo")
    @Column(precision = 15, scale = 2)
    private Integer saldoTotal;

    @LastModifiedDate // Spring lo actualiza solo cada vez que se hace un cambio
    @Column(nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private LocalDateTime ultimaActualizacion;

    @PrePersist
    @PreUpdate
    public void asignarFechaManual() {
        if (this.ultimaActualizacion == null) {
            this.ultimaActualizacion = LocalDateTime.now();
        }
    }
}