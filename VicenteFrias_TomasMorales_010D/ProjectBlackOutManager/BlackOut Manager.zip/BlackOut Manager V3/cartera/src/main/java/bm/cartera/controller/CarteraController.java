package bm.cartera.controller;

import bm.cartera.model.Cartera;
import bm.cartera.Service.CarteraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cartera")
public class CarteraController {

    @Autowired
    private CarteraService carteraService;

    // Crear la cartera inicial para un nuevo tatuador (Saldo 0)
    @PostMapping("/crear/{run}")
    public ResponseEntity<Cartera> crearCartera(@PathVariable Long run) {
        return ResponseEntity.ok(carteraService.crearNuevaCartera(run));
    }

    // Consultar solo el saldo actual del tatuador
    @GetMapping("/saldo/{run}")
    public ResponseEntity<Integer> consultarSaldo(@PathVariable Long run) {
        return ResponseEntity.ok(carteraService.consultarSaldo(run));
    }
}