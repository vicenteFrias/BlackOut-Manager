package com.black_out.service_usuario.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.black_out.service_usuario.model.TipoUsuarios;
import com.black_out.service_usuario.usuario_repository.TipoUsuarioRepository;

@RestController
@RequestMapping("/api/v3/clientes/tipos/")
public class TipoUsuarioController {

    @Autowired
    private TipoUsuarioRepository tipoRepository;

    @GetMapping
    public List<TipoUsuarios> listar(){
        return tipoRepository.findAll();
    }

    @PostMapping
    public TipoUsuarios crear(@RequestBody TipoUsuarios tipo){
        return tipoRepository.save(tipo);
    }

}
