package com.black_out.service_usuario.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "datos_medicos_cliente")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class DatosMedicosCliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String alergias;
    private String enfermedadesCronicas;

    @OneToOne
    @JoinColumn(name = "idClientes", unique = true)
    @JsonIgnore
    private Clientes clientes;

}
