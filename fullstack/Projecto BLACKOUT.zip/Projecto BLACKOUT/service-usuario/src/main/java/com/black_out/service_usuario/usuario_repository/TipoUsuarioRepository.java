package com.black_out.service_usuario.usuario_repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.black_out.service_usuario.model.TipoUsuarios;

public interface TipoUsuarioRepository extends JpaRepository<TipoUsuarios, Long>{

    TipoUsuarios findbyNombre(String nombre);

    TipoUsuarios findByNombreIgnoreCase(String nombre);

}
