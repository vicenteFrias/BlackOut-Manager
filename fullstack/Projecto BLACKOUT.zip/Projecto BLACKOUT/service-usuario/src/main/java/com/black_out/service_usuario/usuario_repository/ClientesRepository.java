package com.black_out.service_usuario.usuario_repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.black_out.service_usuario.model.Clientes;

public interface ClientesRepository extends JpaRepository<Clientes, Long>{

        Clientes findByRun(String run);

        @Query("""
        SELECT c.tipoUsuario.nombre AS tipoUsuario,
                COUNT(c) AS cantidad
        FROM Clientes c
        GROUP BY c.tipoUsuario.nombre
        """)

        List<Object[]> conteoPorTipoUsuario();

        @Query("""
        SELECT c FROM Clientes c
        JOIN FETCH c.datosMedicosCliente dmc
        WHERE dmc IS NOT NULL
        """)

        List<Clientes> findClientesConDatosCompletos();

}
