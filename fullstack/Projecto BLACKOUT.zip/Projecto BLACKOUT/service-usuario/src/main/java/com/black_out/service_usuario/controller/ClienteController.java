package com.black_out.service_usuario.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.black_out.service_usuario.model.Clientes;
import com.black_out.service_usuario.service.ServiceUsuario;

@RestController
@RequestMapping("/api/v3/clientes/")
public class ClienteController {

    @Autowired
    private ServiceUsuario serviceUsuario;

    @GetMapping
    public List<Clientes> listar(){
        return serviceUsuario.listarTodos();
    }

    @GetMapping("/{id")
    public ResponseEntity<Clientes> obtener(@PathVariable Long idClientes){
        return serviceUsuario.buscarPorId(idClientes)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Clientes> crear(@RequestBody Clientes clientes){
        return ResponseEntity.ok(serviceUsuario.guardar(clientes));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long idClientes){
        serviceUsuario.eliminar(idClientes);
        return ResponseEntity.ok().build();
    }

}
