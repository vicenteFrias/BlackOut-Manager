package com.black_out.service_usuario.usuario_repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.black_out.service_usuario.model.Clientes;
import com.black_out.service_usuario.model.DatosMedicosCliente;

@Repository
public interface DatosMedicosClienteRepository extends JpaRepository<DatosMedicosCliente, Long>{

    DatosMedicosCliente findByClientes(Clientes clientes);

    DatosMedicosCliente findByClientesId(Long clientesId);

}
