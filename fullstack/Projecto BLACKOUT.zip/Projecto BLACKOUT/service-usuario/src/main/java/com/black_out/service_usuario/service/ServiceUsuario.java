package com.black_out.service_usuario.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.black_out.service_usuario.model.Clientes;
import com.black_out.service_usuario.usuario_repository.ClientesRepository;

import jakarta.transaction.Transactional;


@Service
public class ServiceUsuario {

    @Autowired
    private ClientesRepository clientesRepository;

    public List<Clientes> listarTodos(){
        return clientesRepository.findAll();
    }

    public Optional<Clientes> buscarPorId(Long idClientes){
        return clientesRepository.findById(idClientes);
    }

    @Transactional
    public Clientes guardar(Clientes clientes){

        if(clientes.getDatosMedicos() != null){
            clientes.getDatosMedicos().setClientes(clientes);
        }
        return clientesRepository.save(clientes);
    }

    public void eliminar(Long idClientes){
        clientesRepository.deleteById(idClientes);
    }

}
