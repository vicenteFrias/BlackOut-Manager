package com.black_out.finanzas_services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinanzasServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
