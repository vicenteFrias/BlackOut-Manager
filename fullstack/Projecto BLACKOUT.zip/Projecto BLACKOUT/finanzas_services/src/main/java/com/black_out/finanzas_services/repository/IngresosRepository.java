package com.black_out.finanzas_services.repository;

public interface IngresosRepository {

}
