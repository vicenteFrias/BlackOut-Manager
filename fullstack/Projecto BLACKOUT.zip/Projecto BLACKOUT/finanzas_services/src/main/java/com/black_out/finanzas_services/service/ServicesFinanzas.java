package com.black_out.finanzas_services.service;

public class ServicesFinanzas {

}
