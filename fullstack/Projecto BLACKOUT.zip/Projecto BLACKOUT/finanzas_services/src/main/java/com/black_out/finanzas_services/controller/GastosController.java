package com.black_out.finanzas_services.controller;

public class GastosController {

}
