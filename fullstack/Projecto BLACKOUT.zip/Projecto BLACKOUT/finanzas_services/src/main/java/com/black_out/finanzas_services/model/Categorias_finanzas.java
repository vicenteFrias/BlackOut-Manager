package com.black_out.finanzas_services.model;

public class Categorias_finanzas {

}
