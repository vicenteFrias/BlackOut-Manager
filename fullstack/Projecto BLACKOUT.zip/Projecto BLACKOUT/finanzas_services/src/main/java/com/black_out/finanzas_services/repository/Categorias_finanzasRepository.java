package com.black_out.finanzas_services.repository;

public interface Categorias_finanzasRepository {

}
