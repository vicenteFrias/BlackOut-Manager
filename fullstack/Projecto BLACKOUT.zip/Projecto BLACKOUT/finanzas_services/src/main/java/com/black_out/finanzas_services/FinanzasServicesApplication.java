package com.black_out.finanzas_services;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinanzasServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinanzasServicesApplication.class, args);
	}

}
