package com.black_out.reporting_service.services;

public class ReportingServices {

}
