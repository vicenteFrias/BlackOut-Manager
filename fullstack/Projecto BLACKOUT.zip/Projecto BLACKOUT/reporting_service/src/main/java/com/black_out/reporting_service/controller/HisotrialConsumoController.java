package com.black_out.reporting_service.controller;

public class HisotrialConsumoController {

}
