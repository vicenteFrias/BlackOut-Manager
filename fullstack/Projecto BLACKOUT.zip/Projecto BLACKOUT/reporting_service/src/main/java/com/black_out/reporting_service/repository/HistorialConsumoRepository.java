package com.black_out.reporting_service.repository;

public interface HistorialConsumoRepository {

}
