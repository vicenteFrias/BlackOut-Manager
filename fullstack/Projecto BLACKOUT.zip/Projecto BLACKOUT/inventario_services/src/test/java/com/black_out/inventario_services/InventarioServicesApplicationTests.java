package com.black_out.inventario_services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventarioServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
