package com.black_out.inventario_services.controller;

public class MovimientosController {

}
