package com.black_out.inventario_services;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventarioServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventarioServicesApplication.class, args);
	}

}
