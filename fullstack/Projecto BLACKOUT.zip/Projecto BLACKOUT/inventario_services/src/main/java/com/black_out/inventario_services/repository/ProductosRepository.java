package com.black_out.inventario_services.repository;

public interface ProductosRepository {

}
