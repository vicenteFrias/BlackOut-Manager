package com.black_out.inventario_services.service;

public class InventarioServices {

}
