package com.black_out.booking_services.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.black_out.booking_services.model.Citas;

public interface CitaRepository extends JpaRepository<Citas, Long>{

    List<Citas> findByIdClientes(Long idClientes);

}
