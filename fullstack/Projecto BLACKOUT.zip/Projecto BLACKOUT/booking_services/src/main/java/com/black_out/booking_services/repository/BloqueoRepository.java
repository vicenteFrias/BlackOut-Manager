package com.black_out.booking_services.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.black_out.booking_services.model.Bloqueos_horarios;

public interface BloqueoRepository extends JpaRepository<Bloqueos_horarios, Long>{

}
