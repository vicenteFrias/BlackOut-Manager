package com.black_out.booking_services.controller;

public class BloqueoController {

}
