package com.black_out.booking_services.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "tatuadores")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Tatuadores {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idTatuador;
    private String run;
    private String nombre_tatuador;
    private int telefono;
    private String activo;

    @ManyToOne
    @JoinColumn(name= "especialidad_id")
    private Especialidad especialidad;

}
