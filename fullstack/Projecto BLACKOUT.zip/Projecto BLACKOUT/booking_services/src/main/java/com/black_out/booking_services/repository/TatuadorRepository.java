package com.black_out.booking_services.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.black_out.booking_services.model.Tatuadores;

public interface TatuadorRepository extends JpaRepository<Tatuadores, Long>{

}
