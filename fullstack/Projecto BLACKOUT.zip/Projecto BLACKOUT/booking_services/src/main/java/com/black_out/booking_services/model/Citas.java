package com.black_out.booking_services.model;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Citas")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Citas {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idCita;
    private Tatuadores idTatuador;
    private LocalDateTime fechaHora;
    private String descDiseno;
    private String estado;
    private int precioTotal;

    private Long idClientes;

    @ManyToOne
    private Tatuadores tatuadores;

    @Transient
    private Object datosClientes;

}
