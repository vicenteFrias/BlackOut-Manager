package com.black_out.booking_services.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.black_out.booking_services.model.Especialidad;

public interface EspecialidadRepository extends JpaRepository<Especialidad, Long>{

}
