package com.black_out.booking_services.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.black_out.booking_services.model.Citas;
import com.black_out.booking_services.model.Especialidad;
import com.black_out.booking_services.model.Tatuadores;
import com.black_out.booking_services.repository.CitaRepository;
import com.black_out.booking_services.repository.EspecialidadRepository;
import com.black_out.booking_services.repository.TatuadorRepository;

@Service
public class AgendaServices {

    @Autowired
    private CitaRepository citaRepository;
    @Autowired
    private WebClient.Builder webClientBuilder;
    @Autowired
    private TatuadorRepository tatuadorRepository;

    public Citas guardarAtencion(Citas cita){
        
        Citas guardada = citaRepository.save(cita);
        if(guardada.getTatuadores() != null && guardada.getTatuadores().getIdTatuador() != null){
            tatuadorRepository.findById(guardada.getTatuadores().getIdTatuador())
                .ifPresent(guardada::setTatuadores);
        }
        Citas completa = citaRepository.findById(guardada.getIdCita())
                .orElse(guardada);

        return enriquecerConCliente(completa);
    }

    public Citas obtenerCitaCompleta(Long id){
        Citas cita = citaRepository.findById(id).orElse(null);
        if(cita != null){
            return enriquecerConCliente(cita);
        }
        return null;
    }
    public List<Citas> listarTodas(){
        return citaRepository.findAll();
    }

    @Autowired
    private EspecialidadRepository especialidadRepository;

    public Especialidad guardarEspecialidad(Especialidad especialidad){
        return especialidadRepository.save(especialidad);
    }

    public List<Especialidad> listarEspecialidad(){
        return especialidadRepository.findAll();
    }

    public Tatuadores guardarMedico(Tatuadores tatuador){
        return tatuadorRepository.save(tatuador);
    }

    public List<Tatuadores> listarTatuadores(){
        return tatuadorRepository.findAll();
    }

    private Citas enriquecerConCliente(Citas cita){
        if(cita.getIdClientes()!= null){
            try{
                Object clientes = webClientBuilder.build()
                        .get()
                        .uri("http://localhost:8090/api/v3/clientes/" + cita.getIdClientes())
                        .retrieve()
                        .bodyToMono(Object.class)
                        .block();
                cita.setDatosClientes(clientes);

            }catch(Exception e){
                cita.setDatosClientes("informacion de cliente no disponible actualmente");
            }
        }
        return cita;
    }

}
