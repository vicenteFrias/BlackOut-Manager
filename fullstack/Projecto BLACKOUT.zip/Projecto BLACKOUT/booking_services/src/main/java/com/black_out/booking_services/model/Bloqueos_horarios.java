package com.black_out.booking_services.model;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "bloqueos_horarios")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Bloqueos_horarios {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idBloqueo;
    private Long id_tatuador;
    private LocalDateTime inicio;
    private LocalDateTime fin;
    private String motivo;

    @OneToMany
    @JoinColumn(name= "Tatuador_id")
    private Tatuadores tatuador;
}
